import type { Express } from "express";
import type { Server } from "http";
import express from "express";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { registerAuthRoutes, setupAuth } from "./replit_integrations/auth";
import { getStripeSync, getStripePublishableKey } from "./stripeClient";
import { stripeService } from "./stripeService";
import { WebhookHandlers } from "./webhookHandlers";
import { runMigrations } from "stripe-replit-sync";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic({
  apiKey: process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL,
});

async function initStripe() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    console.warn('DATABASE_URL not set, skipping Stripe initialization');
    return;
  }

  try {
    console.log('Initializing Stripe schema...');
    await runMigrations({ databaseUrl, schema: 'stripe' });
    console.log('Stripe schema ready');

    const stripeSync = await getStripeSync();

    console.log('Setting up managed webhook...');
    const webhookBaseUrl = `https://${process.env.REPLIT_DOMAINS?.split(',')[0]}`;
    await stripeSync.findOrCreateManagedWebhook(`${webhookBaseUrl}/api/stripe/webhook`);

    console.log('Syncing Stripe data...');
    stripeSync.syncBackfill().then(() => console.log('Stripe data synced')).catch(console.error);
  } catch (error) {
    console.error('Failed to initialize Stripe:', error);
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Initialize Stripe first
  await initStripe();

  // Stripe webhook BEFORE express.json()
  app.post(
    '/api/stripe/webhook',
    express.raw({ type: 'application/json' }),
    async (req, res) => {
      const signature = req.headers['stripe-signature'];
      if (!signature) return res.status(400).json({ error: 'Missing stripe-signature' });

      try {
        const sig = Array.isArray(signature) ? signature[0] : signature;
        await WebhookHandlers.processWebhook(req.body as Buffer, sig);
        res.status(200).json({ received: true });
      } catch (error: any) {
        console.error('Webhook error:', error.message);
        res.status(400).json({ error: 'Webhook processing error' });
      }
    }
  );

  // Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // === STRIPE ROUTES ===
  app.get('/api/stripe/publishable-key', async (req, res) => {
    try {
      const key = await getStripePublishableKey();
      res.json({ publishableKey: key });
    } catch (error) {
      res.status(500).json({ error: 'Failed to get publishable key' });
    }
  });

  app.get('/api/products', async (req, res) => {
    const products = await storage.listProducts();
    res.json({ data: products });
  });

  app.get('/api/products-with-prices', async (req, res) => {
    const rows = await storage.listProductsWithPrices();
    const productsMap = new Map();
    for (const row of rows as any[]) {
      if (!productsMap.has(row.product_id)) {
        productsMap.set(row.product_id, {
          id: row.product_id,
          name: row.product_name,
          description: row.product_description,
          active: row.product_active,
          prices: []
        });
      }
      if (row.price_id) {
        productsMap.get(row.product_id).prices.push({
          id: row.price_id,
          unit_amount: row.unit_amount,
          currency: row.currency,
          recurring: row.recurring,
        });
      }
    }
    res.json({ data: Array.from(productsMap.values()) });
  });

  app.post('/api/checkout', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const { priceId } = req.body;

    try {
      const user = await storage.getUser(userId);
      const profile = await storage.getUserProfile(userId);

      let customerId = profile?.stripeCustomerId;
      if (!customerId && user?.email) {
        const customer = await stripeService.createCustomer(user.email, userId);
        await storage.updateUserProfile(userId, { stripeCustomerId: customer.id });
        customerId = customer.id;
      }

      if (!customerId) {
        return res.status(400).json({ error: 'Could not create customer' });
      }

      const session = await stripeService.createCheckoutSession(
        customerId,
        priceId,
        `${req.protocol}://${req.get('host')}/checkout/success`,
        `${req.protocol}://${req.get('host')}/checkout/cancel`
      );

      res.json({ url: session.url });
    } catch (error: any) {
      console.error('Checkout error:', error);
      res.status(500).json({ error: 'Failed to create checkout session' });
    }
  });

  app.post('/api/customer-portal', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;

    const profile = await storage.getUserProfile(userId);
    if (!profile?.stripeCustomerId) {
      return res.status(400).json({ error: 'No subscription found' });
    }

    const session = await stripeService.createCustomerPortalSession(
      profile.stripeCustomerId,
      `${req.protocol}://${req.get('host')}/profile`
    );

    res.json({ url: session.url });
  });

  // === APP ROUTES ===

  // Preferences / Profile
  app.get(api.preferences.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    
    const profile = await storage.getUserProfile(userId);
    if (!profile) return res.status(404).json({ message: "Profile not found" });
    
    res.json(profile);
  });

  app.put(api.preferences.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;

    try {
      const input = api.preferences.update.input.parse(req.body);
      const updated = await storage.updateUserProfile(userId, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Jobs
  app.get(api.jobs.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const scan = req.query.scan === "true";

    if (scan) {
      await seedMockJobs();
    }

    const allJobs = await storage.getJobs();
    const profile = await storage.getUserProfile(userId);
    
    const scoredJobs = allJobs.map(job => {
      let score = 50;
      if (profile?.industries?.includes(job.industry || "")) score += 30;
      if (profile?.location && job.location.includes(profile.location.split(',')[0])) score += 20;
      return { ...job, matchScore: Math.min(100, score) };
    }).sort((a, b) => b.matchScore - a.matchScore);

    res.json(scoredJobs);
  });

  // Applications
  app.get(api.applications.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    
    const apps = await storage.getApplications(userId);
    res.json(apps);
  });

  app.post(api.applications.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;

    try {
      const { jobId, resumeUsed, matchScore, autoApplied } = req.body;

      // 7-day duplicate prevention
      const canApply = await storage.canApplyToJob(userId, jobId);
      if (!canApply) {
        return res.status(400).json({ message: "Already applied to this job in the last 7 days" });
      }

      // Get job details for snapshot
      const job = await storage.getJobById(jobId);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      const appData = {
        userId,
        jobId,
        jobTitle: job.title,
        company: job.company,
        location: job.location,
        source: job.source,
        status: "applied",
        resumeUsed,
        matchScore,
        autoApplied: autoApplied || false,
      };

      const newApp = await storage.createApplication(appData);
      res.status(201).json(newApp);
    } catch (err) {
      res.status(400).json({ message: "Invalid application data" });
    }
  });

  // Resumes
  app.get(api.resumes.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    
    const resumes = await storage.getTailoredResumes(userId);
    res.json(resumes);
  });

  app.post(api.resumes.generate.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;

    const profile = await storage.getUserProfile(userId);
    if (!profile?.baseResume || !profile.industries?.length) {
      return res.status(400).json({ message: "Please upload a resume and select industries first." });
    }

    // Delete old resumes before generating new ones
    await storage.deleteTailoredResumes(userId);

    const generatedResumes = [];
    
    for (const industry of profile.industries) {
      const prompt = `You are an expert resume writer. Rewrite the following resume to be perfectly tailored for the "${industry}" industry in Australia.

Focus on:
- Highlighting relevant skills and experience for ${industry}
- Using Australian job market terminology
- Making the resume ATS-friendly
- Keeping it professional and concise

Original Resume:
${profile.baseResume}

Output ONLY the tailored resume text, nothing else.`;

      try {
        const message = await anthropic.messages.create({
          model: "claude-sonnet-4-5",
          max_tokens: 2048,
          messages: [{ role: "user", content: prompt }],
        });
        
        const content = message.content[0];
        const resumeText = content.type === "text" ? content.text : "Could not generate resume.";
        
        const resumeData = {
          userId,
          industry,
          content: resumeText,
          coverLetterTemplate: profile.baseCoverLetter,
          isEdited: false
        };

        const newResume = await storage.createTailoredResume(resumeData);
        generatedResumes.push(newResume);
      } catch (error) {
        console.error(`Error generating resume for ${industry}:`, error);
        const mockResume = await storage.createTailoredResume({
          userId,
          industry,
          content: `Tailored Resume for ${industry}\n\n${profile.baseResume}\n\n[AI Generation Failed - Using Original]`,
          coverLetterTemplate: profile.baseCoverLetter,
          isEdited: false
        });
        generatedResumes.push(mockResume);
      }
    }

    res.json(generatedResumes);
  });

  app.put(api.resumes.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const id = parseInt(req.params.id);
      const input = api.resumes.update.input.parse(req.body);
      const updated = await storage.updateTailoredResume(id, input);
      if (!updated) return res.sendStatus(404);
      res.json(updated);
    } catch (err) {
      res.sendStatus(400);
    }
  });

  // Trigger manual auto-apply run (for testing)
  app.post('/api/auto-apply/run', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const { autoApplyService } = await import('./autoApplyService');
    autoApplyService.runAutoApply().catch(console.error);
    
    res.json({ message: 'Auto-apply job triggered' });
  });

  // Get auto-apply stats
  app.get('/api/stats', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;

    const apps = await storage.getApplications(userId);
    const profile = await storage.getUserProfile(userId);
    
    // This month's applications
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthlyApps = apps.filter(app => app.appliedAt && new Date(app.appliedAt) >= monthStart);
    
    // Today's applications
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayApps = apps.filter(app => app.appliedAt && new Date(app.appliedAt) >= today);

    res.json({
      totalApplications: apps.length,
      monthlyApplications: monthlyApps.length,
      dailyApplications: todayApps.length,
      autoModeEnabled: profile?.autoMode || false,
      dailyLimit: profile?.dailyLimit || 5,
      subscriptionStatus: profile?.subscriptionStatus || 'trial',
      monthlyQuotaProgress: Math.round((monthlyApps.length / 20) * 100),
    });
  });

  // Generate Workforce Australia report
  app.get('/api/applications/report', async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;

    const apps = await storage.getApplications(userId);
    
    let report = `QuotaFlow Job Search Report - For Workforce Australia\nGenerated: ${new Date().toLocaleDateString('en-AU')}\n\nTotal Applications: ${apps.length}\n\n`;
    
    apps.forEach((app, index) => {
      const date = app.appliedAt ? new Date(app.appliedAt).toLocaleDateString('en-AU') : 'N/A';
      const time = app.appliedAt ? new Date(app.appliedAt).toLocaleTimeString('en-AU', { hour: '2-digit', minute: '2-digit' }) : '';
      
      report += `${index + 1}. ${app.jobTitle || 'Unknown Position'}\n`;
      report += `   Company: ${app.company || 'Unknown'}\n`;
      report += `   Location: ${app.location || 'Unknown'}\n`;
      report += `   Applied Via: ${app.source || 'QuotaFlow'}\n`;
      report += `   Date: ${date} at ${time}\n`;
      report += `   Resume Used: ${app.resumeUsed || 'Default'}\n\n`;
    });

    res.json({ report });
  });

  // Site metrics temporarily disabled for publishing

  return httpServer;
}

// Seed mock jobs for demo
async function seedMockJobs() {
  const existing = await storage.getJobs();
  if (existing.length > 0) return;

  const mockJobs = [
    {
      title: 'Customer Service Representative',
      company: 'Telstra',
      location: 'Brisbane CBD, QLD',
      salary: 60000,
      type: 'Full-time',
      source: 'Seek',
      industry: 'Retail & Customer Service',
      description: 'Handle customer inquiries and resolve issues. Call center experience preferred.',
    },
    {
      title: 'Warehouse Picker',
      company: 'Amazon Australia',
      location: 'Brisbane Airport, QLD',
      salary: 58000,
      type: 'Full-time',
      source: 'Indeed',
      industry: 'Warehouse & Logistics',
      description: 'Pick and pack orders in fast-paced warehouse environment.',
    },
    {
      title: 'Retail Sales Assistant',
      company: 'Kmart',
      location: 'Fortitude Valley, QLD',
      salary: 55000,
      type: 'Casual',
      source: 'Seek',
      industry: 'Retail & Customer Service',
      description: 'Assist customers on the floor, process transactions.',
    },
    {
      title: 'Personal Trainer',
      company: 'Fitness First',
      location: 'South Brisbane, QLD',
      salary: 58000,
      type: 'Full-time',
      source: 'Seek',
      industry: 'Health & Fitness',
      description: 'Passionate PT needed for growing gym. Cert III/IV required.',
    },
    {
      title: 'Administration Officer',
      company: 'Queensland Health',
      location: 'Brisbane CBD, QLD',
      salary: 65000,
      type: 'Full-time',
      source: 'Indeed',
      industry: 'Administration & Office',
      description: 'Provide administrative support in busy healthcare setting.',
    },
  ];

  for (const job of mockJobs) {
    await storage.createJob(job);
  }
}
