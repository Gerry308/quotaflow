import React, { useState } from 'react';
import { 
  Zap, 
  FileText, 
  CheckCircle, 
  TrendingUp, 
  Clock, 
  Target,
  Settings,
  BarChart3,
  Mail,
  Filter,
  Upload,
  ChevronRight,
  Star,
  Shield,
  MapPin,
  DollarSign,
  Calendar,
  Send,
  Edit2,
  Save,
  X,
  Bell,
  Download,
  Phone
} from 'lucide-react';

const QuotaFlowApp = () => {
  const [currentPage, setCurrentPage] = useState('landing');
  const [step, setStep] = useState(1);
  const [editingResume, setEditingResume] = useState(null);
  const [editedContent, setEditedContent] = useState('');
  
  const [userData, setUserData] = useState({
    resume: '',
    coverLetter: '',
    industries: [],
    location: 'Brisbane, QLD',
    radiusKm: 15,
    salaryMin: 50000,
    phoneNumber: '',
    dailyLimit: 5,
    autoMode: false
  });

  const [tailoredResumes, setTailoredResumes] = useState({});
  const [applications, setApplications] = useState([
    { id: 1, company: 'Telstra', role: 'Customer Service Representative', location: 'Brisbane CBD', applied: 'Today', status: 'auto', salary: '$60,000', industry: 'Retail & Customer Service' },
    { id: 2, company: 'Big W', role: 'Retail Sales Assistant', location: 'Brisbane CBD', applied: 'Today', status: 'auto', salary: '$55,000', industry: 'Retail & Customer Service' },
    { id: 3, company: 'Amazon Australia', role: 'Warehouse Picker', location: 'Brisbane Airport', applied: 'Yesterday', status: 'auto', salary: '$58,000', industry: 'Warehouse & Logistics' },
    { id: 4, company: 'Fitness First', role: 'Personal Trainer', location: 'Fortitude Valley', applied: 'Yesterday', status: 'manual', salary: '$58,000', industry: 'Health & Fitness' },
    { id: 5, company: 'Woolworths', role: 'Store Manager', location: 'Chermside', applied: '2 days ago', status: 'auto', salary: '$65,000', industry: 'Retail & Customer Service' }
  ]);

  const [monthlyQuota] = useState(20);
  const totalApplications = applications.length;
  const autoApplied = applications.filter(a => a.status === 'auto').length;
  const manual = applications.filter(a => a.status === 'manual').length;

  const industries = [
    'Retail & Customer Service',
    'Hospitality & Food Service',
    'Warehouse & Logistics',
    'Administration & Office',
    'Healthcare & Support',
    'Construction & Trades',
    'IT & Technology',
    'Sales & Marketing',
    'Education & Childcare',
    'Manufacturing & Production',
    'Health & Fitness'
  ];

  const handleIndustryToggle = (industry) => {
    if (userData.industries.includes(industry)) {
      setUserData({
        ...userData,
        industries: userData.industries.filter(i => i !== industry)
      });
    } else if (userData.industries.length < 3) {
      setUserData({
        ...userData,
        industries: [...userData.industries, industry]
      });
    }
  };

  const generateTailoredResumes = () => {
    const resumes = {};
    userData.industries.forEach(industry => {
      resumes[industry] = {
        summary: getTailoredSummary(industry),
        skills: getIndustrySkills(industry),
        base: userData.resume
      };
    });
    setTailoredResumes(resumes);
  };

  const getTailoredSummary = (industry) => {
    const summaries = {
      'Retail & Customer Service': 'Enthusiastic professional with proven track record in delivering exceptional customer experiences.',
      'Health & Fitness': 'Passionate fitness professional dedicated to helping clients achieve their health goals.',
      'Warehouse & Logistics': 'Reliable and safety-focused warehouse professional with strong organizational skills.',
      'Hospitality & Food Service': 'Customer-focused hospitality professional with excellent service skills.',
      'IT & Technology': 'Technical professional with strong problem-solving abilities.',
      'Construction & Trades': 'Skilled tradesperson with safety certification and hands-on experience.'
    };
    return summaries[industry] || 'Dedicated professional with relevant industry experience.';
  };

  const getIndustrySkills = (industry) => {
    const skills = {
      'Retail & Customer Service': '• Customer engagement and sales\n• POS system proficiency\n• Merchandise presentation\n• Inventory management',
      'Health & Fitness': '• Personal training\n• Certificate III/IV in Fitness\n• Program design\n• Client motivation',
      'Warehouse & Logistics': '• Forklift operation\n• Inventory control\n• Pick/pack efficiency\n• WHS compliance',
      'Hospitality & Food Service': '• Food safety certification\n• Customer service\n• Point of sale systems\n• Team coordination',
      'IT & Technology': '• Technical support\n• Software troubleshooting\n• System administration\n• Customer communication',
      'Construction & Trades': '• Trade certifications\n• Safety protocols\n• Tool operation\n• Project management'
    };
    return skills[industry] || '• Industry experience\n• Strong work ethic\n• Team collaboration\n• Problem solving';
  };

  // Landing Page Component
  const LandingPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-800">
      <header className="container mx-auto px-6 py-6 flex justify-between items-center">
        <div className="text-white text-3xl font-bold">QuotaFlow</div>
        <button 
          onClick={() => setCurrentPage('login')}
          className="bg-white text-indigo-900 px-6 py-2 rounded-lg font-semibold hover:bg-gray-100 transition"
        >
          Log In
        </button>
      </header>

      <section className="container mx-auto px-6 py-20 text-center">
        <h1 className="text-6xl font-bold text-white mb-6">
          Your job search <span className="text-yellow-400">on Autopilot.</span>
        </h1>
        <p className="text-2xl text-gray-200 mb-12">
          QuotaFlow automatically searches and applies for jobs for you every day. Just set it and forget it!
        </p>
        <button 
          onClick={() => setCurrentPage('setup')}
          className="bg-yellow-400 text-indigo-900 px-10 py-4 rounded-full text-xl font-bold hover:bg-yellow-300 transition shadow-2xl inline-flex items-center gap-2"
        >
          Get Started <ChevronRight />
        </button>
        <div className="mt-8 flex items-center justify-center gap-3">
          <div className="flex -space-x-2">
            <div className="w-10 h-10 rounded-full bg-pink-400 border-2 border-white"></div>
            <div className="w-10 h-10 rounded-full bg-blue-400 border-2 border-white"></div>
            <div className="w-10 h-10 rounded-full bg-green-400 border-2 border-white"></div>
          </div>
          <p className="text-gray-200">Trusted by <strong>500+</strong> Jobseekers</p>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-5xl font-bold text-center mb-4">
            Hit Your Centrelink Quota. <span className="text-indigo-600">No Stress.</span>
          </h2>
          <p className="text-center text-gray-600 text-xl mb-16">Less than a coffee. Cancel anytime.</p>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-indigo-50 p-8 rounded-2xl">
              <div className="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center mb-6">
                <Zap className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Auto-Apply Daily</h3>
              <p className="text-gray-700">Apply to 5 jobs per day automatically. Hit your 20 applications in 4 days.</p>
            </div>

            <div className="bg-purple-50 p-8 rounded-2xl">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mb-6">
                <FileText className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">AI Tailored Resumes</h3>
              <p className="text-gray-700">Upload once. AI creates 3 industry-specific versions perfectly matched.</p>
            </div>

            <div className="bg-green-50 p-8 rounded-2xl">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mb-6">
                <CheckCircle className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">One-Click Reporting</h3>
              <p className="text-gray-700">Copy perfect Workforce Australia reports. No typing. Just paste.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-indigo-900 py-20">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Track Your Progress in Real-Time</h2>
          <p className="text-xl text-gray-200 mb-12">Visual progress bar shows exactly where you are toward your monthly quota</p>
          
          <div className="bg-white rounded-3xl p-8 max-w-3xl mx-auto shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <BarChart3 className="text-indigo-600" size={32} />
                <h3 className="text-2xl font-bold">Centrelink Compliance Meter</h3>
              </div>
              <p className="text-gray-600">20 applications required</p>
            </div>
            <div className="text-6xl font-bold text-indigo-600 mb-2">15/20</div>
            <p className="text-right text-gray-600 mb-4">5 more needed</p>
            <div className="w-full bg-gray-200 rounded-full h-8 mb-6">
              <div className="bg-indigo-600 h-8 rounded-full flex items-center justify-center text-white font-bold" style={{width: '75%'}}>
                75%
              </div>
            </div>
            <div className="flex gap-4 justify-center">
              <div className="bg-indigo-100 px-6 py-3 rounded-lg flex items-center gap-2">
                <CheckCircle className="text-indigo-600" size={20} />
                <span className="font-semibold">10 Auto-Applied</span>
              </div>
              <div className="bg-green-100 px-6 py-3 rounded-lg flex items-center gap-2">
                <CheckCircle className="text-green-600" size={20} />
                <span className="font-semibold">5 Manual</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16">What People Say</h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <div className="bg-indigo-50 p-8 rounded-2xl">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-purple-400 rounded-full"></div>
                <div>
                  <h4 className="font-bold text-lg">Sarah M.</h4>
                  <p className="text-gray-600">Brisbane JobSeeker</p>
                </div>
              </div>
              <p className="text-gray-700 italic mb-4">"I used to stress every month about hitting 20 applications. Now I hit my quota in the first week and spend the rest finding work I actually want. Game changer."</p>
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => <Star key={i} className="text-yellow-400 fill-yellow-400" size={20} />)}
              </div>
            </div>

            <div className="bg-green-50 p-8 rounded-2xl">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-green-400 rounded-full"></div>
                <div>
                  <h4 className="font-bold text-lg">David K.</h4>
                  <p className="text-gray-600">Melbourne JobSeeker</p>
                </div>
              </div>
              <p className="text-gray-700 italic mb-4">"My job provider loves the reports. So clean and professional. And the auto-apply saved me hours every week. Worth way more than $2."</p>
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => <Star key={i} className="text-yellow-400 fill-yellow-400" size={20} />)}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-br from-indigo-50 to-purple-50 py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16">
            Simple Pricing. <span className="text-indigo-600">No Surprises.</span>
          </h2>
          
          <div className="max-w-lg mx-auto bg-white rounded-3xl shadow-2xl p-12 border-4 border-indigo-600">
            <div className="text-center mb-8">
              <div className="text-6xl font-bold text-indigo-600 mb-2">$2</div>
              <p className="text-gray-600 text-xl">per month</p>
            </div>
            
            <div className="space-y-4 mb-8">
              {[
                'Auto-apply to 20-30 jobs/month',
                'AI-tailored resumes (3 industries)',
                'Personalized cover letters',
                'Email notifications',
                'Workforce Australia reports',
                'Duplicate prevention',
                'Distance & salary filters',
                'Progress tracking'
              ].map((feature, i) => (
                <div key={i} className="flex items-center gap-3">
                  <CheckCircle className="text-green-500 flex-shrink-0" size={24} />
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
            
            <button 
              onClick={() => setCurrentPage('setup')}
              className="w-full bg-indigo-600 text-white py-4 rounded-xl text-xl font-bold hover:bg-indigo-700 transition"
            >
              Start Free Trial
            </button>
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-br from-purple-900 via-indigo-900 to-purple-800 py-20">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-5xl font-bold text-white mb-6">Stop Stressing. Start Applying.</h2>
          <p className="text-2xl text-gray-200 mb-12">Join 500+ Aussies who've taken back their time</p>
          <button 
            onClick={() => setCurrentPage('setup')}
            className="bg-yellow-400 text-indigo-900 px-12 py-5 rounded-full text-2xl font-bold hover:bg-yellow-300 transition shadow-2xl inline-flex items-center gap-2"
          >
            Get Started Free <ChevronRight size={32} />
          </button>
        </div>
      </section>

      <footer className="bg-indigo-950 text-white py-8">
        <div className="container mx-auto px-6 text-center">
          <p className="mb-4">© 2025 QuotaFlow. Built for Aussie JobSeekers. Centrelink compliant.</p>
          <div className="flex justify-center gap-8">
            <a href="#" className="hover:text-yellow-400">Privacy</a>
            <a href="#" className="hover:text-yellow-400">Terms</a>
            <a href="#" className="hover:text-yellow-400">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );

  // Setup Wizard
  const SetupWizard = () => (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50">
      <div className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-indigo-900 mb-4">Let's Get You Set Up</h1>
          <div className="flex justify-center gap-2 mb-4">
            {[1,2,3,4,5].map(i => (
              <div key={i} className={`w-12 h-2 rounded-full ${i <= step ? 'bg-indigo-600' : 'bg-gray-300'}`}></div>
            ))}
          </div>
          <p className="text-gray-600">Step {step} of 5</p>
        </div>

        <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl p-8">
          {step === 1 && (
            <div>
              <div className="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center mb-6 mx-auto">
                <Upload className="text-white" size={32} />
              </div>
              <h2 className="text-3xl font-bold text-center mb-2">Upload Your Resume</h2>
              <p className="text-center text-gray-600 mb-8">Paste your current resume content</p>
              
              <textarea 
                className="w-full border-2 border-gray-300 rounded-lg p-4 h-64 font-mono text-sm"
                placeholder="John Smith
Brisbane, QLD | john@email.com | 0400 123 456

PROFESSIONAL SUMMARY
Experienced professional with strong work ethic...

WORK EXPERIENCE
[Your experience here]

EDUCATION
[Your education here]"
                value={userData.resume}
                onChange={(e) => setUserData({...userData, resume: e.target.value})}
              />
            </div>
          )}

          {step === 2 && (
            <div>
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mb-6 mx-auto">
                <FileText className="text-white" size={32} />
              </div>
              <h2 className="text-3xl font-bold text-center mb-2">Cover Letter Template</h2>
              <p className="text-center text-gray-600 mb-8">We'll customize this for each application</p>
              
              <textarea 
                className="w-full border-2 border-gray-300 rounded-lg p-4 h-64 font-mono text-sm"
                placeholder="Dear Hiring Manager,

I am writing to express my interest in the [POSITION] role at [COMPANY].

[Your content here - we'll tailor this automatically]

I look forward to the opportunity to discuss my application further.

Kind regards,
[Your name]"
                value={userData.coverLetter}
                onChange={(e) => setUserData({...userData, coverLetter: e.target.value})}
              />
            </div>
          )}

          {step === 3 && (
            <div>
              <div className="w-16 h-16 bg-pink-600 rounded-full flex items-center justify-center mb-6 mx-auto">
                <Target className="text-white" size={32} />
              </div>
              <h2 className="text-3xl font-bold text-center mb-2">Select Industries</h2>
              <p className="text-center text-gray-600 mb-8">Choose up to 3 industries for tailored resumes</p>
              
              <div className="grid grid-cols-2 gap-3">
                {industries.map(industry => (
                  <button
                    key={industry}
                    onClick={() => handleIndustryToggle(industry)}
                    className={`p-4 rounded-lg border-2 font-semibold transition ${
                      userData.industries.includes(industry)
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-900'
                        : 'border-gray-300 hover:border-indigo-300'
                    }`}
                  >
                    {industry}
                  </button>
                ))}
              </div>
              <p className="text-center text-gray-600 mt-4">Selected: {userData.industries.length}/3</p>
            </div>
          )}

          {step === 4 && (
            <div>
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mb-6 mx-auto">
                <Settings className="text-white" size={32} />
              </div>
              <h2 className="text-3xl font-bold text-center mb-2">Job Preferences</h2>
              <p className="text-center text-gray-600 mb-8">Set your search criteria</p>
              
              <div className="space-y-6">
                <div>
                  <label className="block font-semibold mb-2">Location</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 text-gray-400" size={20} />
                    <input 
                      type="text" 
                      className="w-full border-2 border-gray-300 rounded-lg p-3 pl-10"
                      value={userData.location}
                      onChange={(e) => setUserData({...userData, location: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold mb-2">Search Radius: {userData.radiusKm}km</label>
                  <input 
                    type="range" 
                    min="5" 
                    max="50" 
                    value={userData.radiusKm}
                    onChange={(e) => setUserData({...userData, radiusKm: parseInt(e.target.value)})}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-2">Minimum Salary: ${userData.salaryMin.toLocaleString()}</label>
                  <input 
                    type="range" 
                    min="40000" 
                    max="100000" 
                    step="5000"
                    value={userData.salaryMin}
                    onChange={(e) => setUserData({...userData, salaryMin: parseInt(e.target.value)})}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-2">Applications Per Day: {userData.dailyLimit}</label>
                  <input 
                    type="range" 
                    min="3" 
                    max="10" 
                    value={userData.dailyLimit}
                    onChange={(e) => setUserData({...userData, dailyLimit: parseInt(e.target.value)})}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-2">Email (for notifications)</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 text-gray-400" size={20} />
                    <input 
                      type="email" 
                      className="w-full border-2 border-gray-300 rounded-lg p-3 pl-10"
                      placeholder="your@email.com"
                      value={userData.email || ''}
                      onChange={(e) => setUserData({...userData, email: e.target.value})}
                    />
                  </div>
                  <p className="text-sm text-gray-500 mt-2">Get notified when applications are submitted (free!)</p>
                </div>
              </div>
            </div>
          )}

          {step === 5 && (
            <div>
              <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mb-6 mx-auto">
                <CheckCircle className="text-white" size={32} />
              </div>
              <h2 className="text-3xl font-bold text-center mb-2">Review Your Tailored Resumes</h2>
              <p className="text-center text-gray-600 mb-8">We've created specialized versions for each industry</p>
              
              {userData.industries.length > 0 ? (
                <div className="space-y-4">
                  {userData.industries.map((industry, idx) => (
                    <div key={idx} className="border-2 border-gray-200 rounded-lg p-6">
                      <div className="flex justify-between items-start mb-4">
                        <h3 className="font-bold text-xl text-indigo-900">{industry}</h3>
                        {editingResume === industry ? (
                          <div className="flex gap-2">
                            <button 
                              onClick={() => {
                                setTailoredResumes({
                                  ...tailoredResumes,
                                  [industry]: {
                                    ...tailoredResumes[industry],
                                    summary: editedContent
                                  }
                                });
                                setEditingResume(null);
                              }}
                              className="text-green-600 hover:text-green-700"
                            >
                              <Save size={20} />
                            </button>
                            <button 
                              onClick={() => setEditingResume(null)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <X size={20} />
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => {
                              setEditingResume(industry);
                              setEditedContent(tailoredResumes[industry]?.summary || getTailoredSummary(industry));
                            }}
                            className="text-indigo-600 hover:text-indigo-700"
                          >
                            <Edit2 size={20} />
                          </button>
                        )}
                      </div>
                      
                      <div className="bg-gray-50 rounded-lg p-4 mb-4">
                        <p className="font-semibold mb-2">Professional Summary:</p>
                        {editingResume === industry ? (
                          <textarea
                            className="w-full border-2 border-indigo-300 rounded p-2 h-24"
                            value={editedContent}
                            onChange={(e) => setEditedContent(e.target.value)}
                          />
                        ) : (
                          <p className="text-gray-700">{tailoredResumes[industry]?.summary || getTailoredSummary(industry)}</p>
                        )}
                      </div>
                      
                      <div className="bg-gray-50 rounded-lg p-4">
                        <p className="font-semibold mb-2">Industry-Specific Skills:</p>
                        <p className="text-gray-700 whitespace-pre-line">{getIndustrySkills(industry)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">No industries selected. Go back to step 3.</p>
                </div>
              )}

              <div className="bg-yellow-50 border-2 border-yellow-400 rounded-xl p-6 mt-6">
                <div className="flex gap-3">
                  <Shield className="text-yellow-600 flex-shrink-0" size={24} />
                  <div>
                    <h4 className="font-bold mb-2">Ready to Start!</h4>
                    <p className="text-sm text-gray-700">Your settings: Within {userData.radiusKm}km, ${userData.salaryMin.toLocaleString()}+ salary, {userData.dailyLimit} applications daily</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-between mt-8">
            <button 
              onClick={() => step > 1 ? setStep(step - 1) : setCurrentPage('landing')}
              className="px-6 py-3 border-2 border-gray-300 rounded-lg font-semibold hover:bg-gray-50"
            >
              Back
            </button>
            <button 
              onClick={() => {
                if (step < 5) {
                  if (step === 3 && userData.industries.length > 0) {
                    generateTailoredResumes();
                  }
                  setStep(step + 1);
                } else {
                  setCurrentPage('dashboard');
                }
              }}
              disabled={step === 3 && userData.industries.length === 0}
              className="px-8 py-3 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 flex items-center gap-2 disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              {step < 5 ? 'Continue' : 'Go to Dashboard'} <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // Dashboard Component
  const Dashboard = () => (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-indigo-600">QuotaFlow</div>
          <div className="flex items-center gap-4">
            <button className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100 rounded-lg">
              <Bell size={20} />
            </button>
            <button className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100 rounded-lg">
              <Settings size={20} />
            </button>
            <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold">
              U
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Welcome back! 👋</h1>
          <p className="text-gray-600">Here's your job application progress</p>
        </div>

        <div className="bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl p-8 mb-8 text-white shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <BarChart3 size={32} />
              <h2 className="text-2xl font-bold">Centrelink Compliance Meter</h2>
            </div>
            <div className="text-right">
              <p className="text-sm opacity-90">{monthlyQuota} applications required</p>
              <p className="text-sm font-semibold">{monthlyQuota - totalApplications} more needed</p>
            </div>
          </div>
          
          <div className="text-6xl font-bold mb-4">{totalApplications}/{monthlyQuota}</div>
          
          <div className="w-full bg-white/20 rounded-full h-6 mb-6">
            <div 
              className="bg-yellow-400 h-6 rounded-full flex items-center justify-center text-indigo-900 font-bold text-sm"
              style={{width: `${Math.min((totalApplications/monthlyQuota)*100, 100)}%`}}
            >
              {Math.round((totalApplications/monthlyQuota)*100)}%
            </div>
          </div>
          
          <div className="flex gap-4">
            <div className="bg-white/20 backdrop-blur px-6 py-3 rounded-lg flex items-center gap-2">
              <Zap size={20} />
              <span className="font-semibold">{autoApplied} Auto-Applied</span>
            </div>
            <div className="bg-white/20 backdrop-blur px-6 py-3 rounded-lg flex items-center gap-2">
              <CheckCircle size={20} />
              <span className="font-semibold">{manual} Manual</span>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 shadow">
            <div className="flex items-center justify-between mb-4">
              <Clock className="text-indigo-600" size={32} />
              <span className="text-2xl font-bold text-indigo-600">{Math.ceil((monthlyQuota - totalApplications) / userData.dailyLimit)}</span>
            </div>
            <p className="text-gray-600">Days to Quota</p>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow">
            <div className="flex items-center justify-between mb-4">
              <TrendingUp className="text-green-600" size={32} />
              <span className="text-2xl font-bold text-green-600">8</span>
            </div>
            <p className="text-gray-600">Interviews Booked</p>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow">
            <div className="flex items-center justify-between mb-4">
              <Mail className="text-purple-600" size={32} />
              <span className="text-2xl font-bold text-purple-600">23</span>
            </div>
            <p className="text-gray-600">Responses Received</p>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow">
            <div className="flex items-center justify-between mb-4">
              <Target className="text-orange-600" size={32} />
              <span className="text-2xl font-bold text-orange-600">92%</span>
            </div>
            <p className="text-gray-600">Match Rate</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow p-6 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Recent Applications</h2>
            <div className="flex gap-2">
              <button className="px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-50 flex items-center gap-2">
                <Filter size={20} />
                Filter
              </button>
            </div>
          </div>
          <div className="space-y-4">
            {applications.slice(0, 5).map((job) => (
              <div key={job.id} className="border-2 border-gray-200 rounded-lg p-4 hover:border-indigo-300 transition">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-bold text-lg">{job.role}</h3>
                      {job.status === 'auto' ? (
                        <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1">
                          <Zap size={12} /> Auto
                        </span>
                      ) : (
                        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold">Manual</span>
                      )}
                    </div>
                    <p className="text-gray-600 mb-1">{job.company}</p>
                    <div className="flex gap-4 text-sm text-gray-500">
                      <span className="flex items-center gap-1"><MapPin size={14} /> {job.location}</span>
                      <span className="flex items-center gap-1"><DollarSign size={14} /> {job.salary}</span>
                      <span className="flex items-center gap-1"><Clock size={14} /> {job.applied}</span>
                    </div>
                  </div>
                  <button className="text-indigo-600 hover:text-indigo-700 font-semibold">View Details</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <button className="bg-white rounded-xl p-6 shadow hover:shadow-lg transition text-left">
            <Download className="text-indigo-600 mb-3" size={32} />
            <h3 className="font-bold text-lg mb-2">Generate Report</h3>
            <p className="text-gray-600 text-sm">Copy your Workforce Australia report</p>
          </button>
          
          <button className="bg-white rounded-xl p-6 shadow hover:shadow-lg transition text-left">
            <Settings className="text-purple-600 mb-3" size={32} />
            <h3 className="font-bold text-lg mb-2">Update Preferences</h3>
            <p className="text-gray-600 text-sm">Change your job search settings</p>
          </button>
          
          <button className="bg-white rounded-xl p-6 shadow hover:shadow-lg transition text-left">
            <Send className="text-green-600 mb-3" size={32} />
            <h3 className="font-bold text-lg mb-2">Add Manual Application</h3>
            <p className="text-gray-600 text-sm">Log a job you applied to yourself</p>
          </button>
        </div>
      </div>
    </div>
  );

  // Login Page
  const LoginPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-800 flex items-center justify-center px-6">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full">
        <h2 className="text-3xl font-bold text-center mb-8">Welcome Back</h2>
        <div className="space-y-4">
          <div>
            <label className="block font-semibold mb-2">Email</label>
            <input type="email" className="w-full border-2 border-gray-300 rounded-lg p-3" placeholder="your@email.com" />
          </div>
          <div>
            <label className="block font-semibold mb-2">Password</label>
            <input type="password" className="w-full border-2 border-gray-300 rounded-lg p-3" placeholder="••••••••" />
          </div>
          <button 
            onClick={() => setCurrentPage('dashboard')}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700"
          >
            Log In
          </button>
        </div>
        <div className="text-center mt-6">
          <p className="text-gray-600">
            Don't have an account? {' '}
            <button onClick={() => setCurrentPage('setup')} className="text-indigo-600 font-semibold">
              Sign up free
            </button>
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="font-sans">
      {currentPage === 'landing' && <LandingPage />}
      {currentPage === 'setup' && <SetupWizard />}
      {currentPage === 'dashboard' && <Dashboard />}
      {currentPage === 'login' && <LoginPage />}
    </div>
  );
};

export default QuotaFlowApp;