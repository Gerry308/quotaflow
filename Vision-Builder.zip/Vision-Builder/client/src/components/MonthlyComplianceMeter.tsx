import { Progress } from "@/components/ui/progress";
import { CheckCircle2, Target } from "lucide-react";

interface MonthlyComplianceMeterProps {
  current: number;
  target?: number;
}

export function MonthlyComplianceMeter({ current, target = 20 }: MonthlyComplianceMeterProps) {
  const percentage = Math.min(100, Math.round((current / target) * 100));
  const isComplete = current >= target;
  
  const now = new Date();
  const monthName = now.toLocaleDateString('en-AU', { month: 'long' });
  const daysLeft = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate() - now.getDate();

  return (
    <div className="bg-card border border-border/50 rounded-2xl p-6 shadow-sm" data-testid="monthly-compliance-meter">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          {isComplete ? (
            <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            </div>
          ) : (
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Target className="w-5 h-5 text-primary" />
            </div>
          )}
          <div>
            <h3 className="font-display font-semibold text-lg">
              {monthName} Quota
            </h3>
            <p className="text-sm text-muted-foreground">
              {isComplete ? 'Quota complete!' : `${daysLeft} days remaining`}
            </p>
          </div>
        </div>
        <div className="text-right">
          <span className="text-3xl font-bold font-display">{current}</span>
          <span className="text-lg text-muted-foreground">/{target}</span>
        </div>
      </div>

      <Progress 
        value={percentage} 
        className="h-3"
        data-testid="progress-bar"
      />
      
      <div className="flex justify-between mt-3 text-sm">
        <span className={isComplete ? "text-green-600 font-medium" : "text-muted-foreground"}>
          {percentage}% complete
        </span>
        <span className="text-muted-foreground">
          {Math.max(0, target - current)} more needed
        </span>
      </div>

      {isComplete && (
        <div className="mt-4 p-3 bg-green-500/10 border border-green-500/20 rounded-xl text-center">
          <p className="text-green-700 dark:text-green-400 font-medium text-sm">
            You've met your Workforce Australia requirement for {monthName}!
          </p>
        </div>
      )}
    </div>
  );
}
