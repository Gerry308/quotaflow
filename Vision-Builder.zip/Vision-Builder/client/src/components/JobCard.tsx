import { MapPin, DollarSign, Building2, Clock, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Job } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";

interface JobCardProps {
  job: Job & { matchScore?: number };
  onApply: (jobId: number) => void;
  isApplied?: boolean;
  isApplying?: boolean;
}

export function JobCard({ job, onApply, isApplied = false, isApplying = false }: JobCardProps) {
  return (
    <div className="group relative bg-card hover:bg-card/80 border border-border/50 hover:border-primary/50 rounded-2xl p-6 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-primary/5 hover:-translate-y-1">
      <div className="mb-4">
        <div className="flex items-start justify-between gap-3 mb-1">
          <h3 className="font-display font-bold text-xl text-foreground group-hover:text-primary transition-colors">
            {job.title}
          </h3>
          {job.matchScore && (
            <div className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1 rounded-full bg-accent/10 text-accent-foreground text-xs font-bold border border-accent/20">
              <ZapIcon className="w-3 h-3 fill-current" />
              {job.matchScore}%
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Building2 className="w-4 h-4" />
          <span className="font-medium">{job.company}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-y-2 gap-x-4 mb-6 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-primary/70" />
          {job.location}
        </div>
        <div className="flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-green-500/70" />
          {job.salary ? `$${(job.salary / 1000).toFixed(0)}k/yr` : "Competitive"}
        </div>
        <div className="flex items-center gap-2 col-span-2">
          <Clock className="w-4 h-4 text-orange-500/70" />
          Posted {job.postedAt ? formatDistanceToNow(new Date(job.postedAt), { addSuffix: true }) : "Recently"}
        </div>
      </div>

      <div className="flex items-center gap-3 mt-auto">
        <Button 
          onClick={() => onApply(job.id)}
          disabled={isApplied || isApplying}
          className={cn(
            "w-full rounded-xl font-semibold shadow-lg transition-all duration-300",
            isApplied 
              ? "bg-green-500/10 text-green-600 hover:bg-green-500/20 shadow-none" 
              : "bg-primary hover:bg-primary/90 hover:shadow-primary/25"
          )}
        >
          {isApplied ? (
            <>
              <CheckCircle className="w-4 h-4 mr-2" />
              Applied
            </>
          ) : isApplying ? (
            "Applying..."
          ) : (
            "Apply Now"
          )}
        </Button>
      </div>
    </div>
  );
}

function ZapIcon({ className }: { className?: string }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
    </svg>
  );
}
