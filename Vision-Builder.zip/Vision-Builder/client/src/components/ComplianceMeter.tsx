import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";
import { motion } from "framer-motion";

interface ComplianceMeterProps {
  current: number;
  total: number;
}

export function ComplianceMeter({ current, total }: ComplianceMeterProps) {
  const percentage = Math.min(100, Math.round((current / total) * 100));
  
  const data = [
    { name: "Completed", value: current },
    { name: "Remaining", value: total - current },
  ];
  
  const COLORS = ["hsl(var(--primary))", "hsl(var(--muted))"];

  return (
    <div className="bg-card border border-border/50 rounded-2xl p-6 shadow-sm relative overflow-hidden">
      <div className="absolute top-0 right-0 p-3 opacity-10">
        <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-accent blur-3xl" />
      </div>

      <h3 className="font-display font-semibold text-lg mb-2">Daily Quota</h3>
      <p className="text-muted-foreground text-sm mb-6">Applications submitted today</p>

      <div className="h-48 relative flex items-center justify-center">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={80}
              startAngle={90}
              endAngle={-270}
              dataKey="value"
              stroke="none"
              cornerRadius={10}
              paddingAngle={5}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span 
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-4xl font-bold font-display text-foreground"
          >
            {percentage}%
          </motion.span>
          <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider mt-1">
            {current}/{total} Goal
          </span>
        </div>
      </div>
      
      <div className="mt-4 flex items-center justify-between text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-primary" />
          <span className="text-muted-foreground">Completed</span>
        </div>
        <div className="font-semibold">{current} Apps</div>
      </div>
    </div>
  );
}
