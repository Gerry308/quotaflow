import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Users, CreditCard, RefreshCw, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function AdminMetrics() {
  const { data: metrics, isLoading, refetch, isRefetching } = useQuery<{ visits: number; subscriptions: number }>({
    queryKey: ["/api/metrics"],
  });

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Site Analytics</h1>
            <p className="text-muted-foreground">Anonymous aggregate counts only</p>
          </div>
          <div className="flex gap-2">
            <Link href="/">
              <Button variant="outline" size="icon" data-testid="button-back-home">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <Button 
              variant="outline" 
              size="icon" 
              onClick={() => refetch()}
              disabled={isRefetching}
              data-testid="button-refresh-metrics"
            >
              <RefreshCw className={`w-4 h-4 ${isRefetching ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-6">
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Total Visits</div>
                  <div className="text-3xl font-bold" data-testid="text-total-visits">
                    {metrics?.visits.toLocaleString() || 0}
                  </div>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Unique sessions tracked (no personal data stored)
              </p>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Subscriptions</div>
                  <div className="text-3xl font-bold" data-testid="text-total-subscriptions">
                    {metrics?.subscriptions.toLocaleString() || 0}
                  </div>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Successful Stripe checkouts
              </p>
            </Card>
          </div>
        )}

        <Card className="p-4">
          <div className="text-sm text-muted-foreground">
            <strong>Privacy Note:</strong> These metrics are completely anonymous. We only track aggregate counts with no personal information, IP addresses, or browsing behavior stored.
          </div>
        </Card>
      </div>
    </div>
  );
}
