import { useState, useEffect } from "react";
import { usePreferences, useUpdatePreferences } from "@/hooks/use-preferences";
import { useResumes, useGenerateResumes, useUpdateResume } from "@/hooks/use-resumes";
import { useJobs } from "@/hooks/use-jobs";
import { useApplications, useApply, useAutoApply } from "@/hooks/use-applications";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Upload, Building2, FileEdit, Search, CheckCircle2, 
  Loader2, MapPin, Zap, ChevronRight, Pencil, Send, Clock,
  Bell, Copy, Download, ArrowLeft
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { useAuth } from "@/hooks/use-auth";

const STEPS = [
  { id: 1, label: "Upload", icon: Upload },
  { id: 2, label: "Industries", icon: Building2 },
  { id: 3, label: "Edit Resumes", icon: FileEdit },
  { id: 4, label: "Find Jobs", icon: Search },
  { id: 5, label: "Track", icon: CheckCircle2 },
];

const AVAILABLE_INDUSTRIES = [
  "Retail & Customer Service",
  "Warehouse & Logistics",
  "Administration & Office",
  "Health & Fitness",
  "Hospitality & Food Service",
  "Construction & Trades",
  "IT & Technology",
  "Sales & Marketing",
];

interface WizardProps {
  isDemo?: boolean;
}

const DEMO_RESUME = `JOHN SMITH
0412 345 678 | john.smith@email.com | Brisbane, QLD

PROFESSIONAL SUMMARY
Experienced operations professional with 10+ years in warehouse management, customer service, and team leadership. Proven track record of improving efficiency and delivering results.

EXPERIENCE
Operations Manager | ABC Logistics | 2020-2024
- Managed warehouse operations and team of 15 staff
- Improved order fulfillment speed by 25%

Customer Service Lead | Retail Corp | 2016-2020
- Led team of 8 customer service representatives
- Achieved 98% customer satisfaction rating

SKILLS
Team Leadership | Inventory Management | Customer Relations | Problem Solving`;

const DEMO_COVER_LETTER = `Dear Hiring Manager,

I am writing to apply for the [Position] at [Company]. With over 10 years of experience in operations and customer service, I am confident I can contribute to your team's success.

My background includes team leadership, process improvement, and delivering excellent customer outcomes.

I look forward to discussing how I can contribute to your organisation.

Kind regards,
John Smith`;

const DEMO_JOBS = [
  { id: 1, title: "Customer Service Representative", company: "Telstra", location: "Brisbane CBD, QLD", salary: 60000, type: "Full-time", source: "Seek", industry: "Retail & Customer Service", matchScore: 100, description: "Handle customer inquiries.", postedAt: new Date() },
  { id: 2, title: "Warehouse Picker", company: "Amazon Australia", location: "Brisbane Airport, QLD", salary: 58000, type: "Full-time", source: "Indeed", industry: "Warehouse & Logistics", matchScore: 100, description: "Pick and pack orders.", postedAt: new Date() },
  { id: 3, title: "Retail Sales Assistant", company: "Kmart", location: "Fortitude Valley, QLD", salary: 55000, type: "Casual", source: "Seek", industry: "Retail & Customer Service", matchScore: 80, description: "Assist customers.", postedAt: new Date() },
  { id: 4, title: "Personal Trainer", company: "Fitness First", location: "South Brisbane, QLD", salary: 58000, type: "Full-time", source: "Seek", industry: "Health & Fitness", matchScore: 100, description: "PT for growing gym.", postedAt: new Date() },
];

const DEMO_APPLICATIONS = [
  { id: 1, jobId: 1, jobTitle: "Customer Service Representative", company: "Telstra", location: "Brisbane CBD, QLD", source: "Seek", status: "applied", autoApplied: true, appliedAt: new Date().toISOString(), matchScore: 100, resumeUsed: "Retail & Customer Service" },
  { id: 2, jobId: 2, jobTitle: "Warehouse Picker", company: "Amazon Australia", location: "Brisbane Airport, QLD", source: "Indeed", status: "applied", autoApplied: true, appliedAt: new Date().toISOString(), matchScore: 100, resumeUsed: "Warehouse & Logistics" },
  { id: 3, jobId: 3, jobTitle: "Retail Sales Assistant", company: "Kmart", location: "Fortitude Valley, QLD", source: "Seek", status: "applied", autoApplied: false, appliedAt: new Date().toISOString(), matchScore: 80, resumeUsed: "Retail & Customer Service" },
];

const DEMO_RESUMES = [
  { id: 1, industry: "Retail & Customer Service", content: "# JOHN SMITH - Retail & Customer Service Resume\n\nExperienced customer service professional with proven track record in retail environments...", isEdited: false },
  { id: 2, industry: "Warehouse & Logistics", content: "# JOHN SMITH - Warehouse & Logistics Resume\n\nOperations manager with extensive warehouse and logistics experience...", isEdited: false },
  { id: 3, industry: "Health & Fitness", content: "# JOHN SMITH - Health & Fitness Resume\n\nDedicated professional with team leadership and wellness focus...", isEdited: false },
];

export default function Wizard({ isDemo = false }: WizardProps) {
  const { logout } = useAuth();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const { data: realPreferences, isLoading: prefsLoading } = usePreferences();
  const { mutate: updatePreferences, isPending: isSaving } = useUpdatePreferences();
  const { data: realResumes, isLoading: resumesLoading } = useResumes();
  const { mutate: generateResumes, isPending: isGenerating } = useGenerateResumes();
  const { data: realJobs, isLoading: jobsLoading } = useJobs();
  const { data: realApplications } = useApplications();
  const { mutate: apply, isPending: isApplying } = useApply();
  const { mutate: autoApply, isPending: isAutoApplying } = useAutoApply();

  const preferences = isDemo ? null : realPreferences;
  const resumes = isDemo ? DEMO_RESUMES : realResumes;
  const jobs = isDemo ? DEMO_JOBS : realJobs;
  const applications = isDemo ? DEMO_APPLICATIONS : realApplications;

  const [baseResume, setBaseResume] = useState(isDemo ? DEMO_RESUME : "");
  const [baseCoverLetter, setBaseCoverLetter] = useState(isDemo ? DEMO_COVER_LETTER : "");
  const [selectedIndustries, setSelectedIndustries] = useState<string[]>(isDemo ? ["Retail & Customer Service", "Warehouse & Logistics", "Health & Fitness"] : []);
  const [location, setLocation] = useState("Brisbane, QLD");
  const [radiusKm, setRadiusKm] = useState(15);
  const [salaryMin, setSalaryMin] = useState(50000);
  const [employmentType, setEmploymentType] = useState("full-time");
  const [autoMode, setAutoMode] = useState(isDemo ? true : false);
  const [dailyLimit, setDailyLimit] = useState(5);
  const [notificationEmail, setNotificationEmail] = useState(isDemo ? "demo@quotaflow.app" : "");
  const [weeklyMode, setWeeklyMode] = useState(false);
  const [editingResume, setEditingResume] = useState<any>(null);
  const [editContent, setEditContent] = useState("");
  const { mutate: updateResume, isPending: isUpdatingResume } = useUpdateResume();
  const [applicationFilter, setApplicationFilter] = useState<"all" | "auto" | "manual">("all");
  const [demoGenerating, setDemoGenerating] = useState(false);

  useEffect(() => {
    if (preferences && !isDemo) {
      setBaseResume(preferences.baseResume || "");
      setBaseCoverLetter(preferences.baseCoverLetter || "");
      setSelectedIndustries(preferences.industries || []);
      setLocation(preferences.location || "Brisbane, QLD");
      setRadiusKm(preferences.radiusKm || 15);
      setSalaryMin(preferences.salaryMin || 50000);
      setEmploymentType(preferences.employmentType || "full-time");
      setAutoMode(preferences.autoMode || false);
      setDailyLimit(preferences.dailyLimit || 5);
      setNotificationEmail(preferences.notificationEmail || "");
      setWeeklyMode(preferences.weeklyMode || false);
    }
  }, [preferences, isDemo]);

  const toggleIndustry = (industry: string) => {
    if (selectedIndustries.includes(industry)) {
      setSelectedIndustries(selectedIndustries.filter(i => i !== industry));
    } else if (selectedIndustries.length < 3) {
      setSelectedIndustries([...selectedIndustries, industry]);
    }
  };

  const saveStep1 = () => {
    if (isDemo) {
      toast({ title: "Demo Mode", description: "Resume saved! Moving to next step." });
      setCurrentStep(2);
      return;
    }
    updatePreferences({ baseResume, baseCoverLetter }, {
      onSuccess: () => setCurrentStep(2)
    });
  };

  const saveStep2AndGenerate = () => {
    if (isDemo) {
      setDemoGenerating(true);
      toast({ title: "Demo Mode", description: "Generating AI-tailored resumes..." });
      setTimeout(() => {
        setDemoGenerating(false);
        setCurrentStep(3);
      }, 2000);
      return;
    }
    updatePreferences({
      industries: selectedIndustries,
      location,
      radiusKm,
      salaryMin,
      employmentType,
      autoMode,
      dailyLimit,
      notificationEmail,
      weeklyMode,
    }, {
      onSuccess: () => {
        generateResumes(undefined, {
          onSuccess: () => setCurrentStep(3)
        });
      }
    });
  };

  const handleApply = (jobId: number) => {
    apply(jobId);
  };

  const handleAutoApply = () => {
    const unappliedJobs = jobs?.filter(j => 
      !applications?.some(a => a.jobId === j.id)
    ).slice(0, dailyLimit) || [];
    
    if (unappliedJobs.length > 0) {
      autoApply(unappliedJobs.map(j => j.id));
    }
  };

  const handleSaveResume = () => {
    if (editingResume) {
      updateResume({ id: editingResume.id, content: editContent }, {
        onSuccess: () => setEditingResume(null)
      });
    }
  };

  const appliedJobIds = new Set(applications?.map(a => a.jobId) || []);
  const unappliedCount = jobs?.filter(j => !appliedJobIds.has(j.id)).length || 0;

  if (prefsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background font-body">
      <header className="border-b border-border/50 bg-card px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white shadow-lg shadow-primary/20">
            <Zap className="w-5 h-5 fill-current" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight">QuotaFlow</span>
        </div>
        <Button variant="ghost" size="sm" onClick={() => logout()} data-testid="button-logout">
          Sign Out
        </Button>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8 overflow-x-auto pb-4">
          {STEPS.map((step, idx) => {
            const Icon = step.icon;
            const isActive = currentStep === step.id;
            const isCompleted = currentStep > step.id;
            
            return (
              <div key={step.id} className="flex items-center flex-shrink-0">
                <div className="flex flex-col items-center">
                  <button
                    onClick={() => isCompleted && setCurrentStep(step.id)}
                    disabled={!isCompleted && !isActive}
                    className={cn(
                      "w-12 h-12 rounded-full flex items-center justify-center transition-all",
                      isActive ? "bg-primary text-white shadow-lg" :
                      isCompleted ? "bg-primary text-white" :
                      "bg-muted text-muted-foreground"
                    )}
                    data-testid={`step-${step.id}`}
                  >
                    <Icon className="w-5 h-5" />
                  </button>
                  <span className={cn(
                    "text-xs mt-2 font-medium",
                    isActive || isCompleted ? "text-foreground" : "text-muted-foreground"
                  )}>
                    {step.label}
                  </span>
                </div>
                {idx < STEPS.length - 1 && (
                  <div className={cn(
                    "w-12 md:w-20 h-1 mx-2 rounded-full",
                    currentStep > step.id ? "bg-primary" : "bg-muted"
                  )} />
                )}
              </div>
            );
          })}
        </div>

        {currentStep === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display font-bold text-2xl mb-2">Step 1: Upload Your Resume</h2>
              <p className="text-muted-foreground">Paste your base resume and cover letter. We'll use AI to tailor them for each industry.</p>
            </div>

            <div className="space-y-4">
              <div>
                <Label className="text-base font-semibold mb-2 block">Base Resume</Label>
                <Textarea
                  value={baseResume}
                  onChange={(e) => setBaseResume(e.target.value)}
                  placeholder="Paste your full resume text here..."
                  className="min-h-[250px] text-sm"
                  data-testid="textarea-base-resume"
                />
              </div>

              <div>
                <Label className="text-base font-semibold mb-2 block">Cover Letter Template</Label>
                <Textarea
                  value={baseCoverLetter}
                  onChange={(e) => setBaseCoverLetter(e.target.value)}
                  placeholder="Paste your cover letter template here..."
                  className="min-h-[200px] text-sm"
                  data-testid="textarea-cover-letter"
                />
              </div>
            </div>

            <Button 
              onClick={saveStep1}
              disabled={isSaving || baseResume.length < 50}
              className="w-full h-14 rounded-xl text-lg gap-2"
              data-testid="button-continue-step1"
            >
              {isSaving ? <Loader2 className="w-5 h-5 animate-spin" /> : null}
              Continue to Industry Selection
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display font-bold text-2xl mb-2">Step 2: Select Target Industries</h2>
              <p className="text-muted-foreground">
                Select exactly 3 industries to continue. This helps us create tailored resumes that highlight your transferable skills across different fields.
              </p>
              <div className="mt-3 flex items-center gap-2">
                <div className={`text-sm font-medium ${selectedIndustries.length === 3 ? 'text-green-600 dark:text-green-400' : 'text-muted-foreground'}`}>
                  {selectedIndustries.length}/3 industries selected
                </div>
                {selectedIndustries.length < 3 && (
                  <span className="text-sm text-amber-600 dark:text-amber-400">
                    — Please select {3 - selectedIndustries.length} more to continue
                  </span>
                )}
                {selectedIndustries.length === 3 && (
                  <span className="text-sm text-green-600 dark:text-green-400">
                    — Ready to continue!
                  </span>
                )}
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {AVAILABLE_INDUSTRIES.map((industry) => {
                const isSelected = selectedIndustries.includes(industry);
                return (
                  <Button
                    key={industry}
                    variant={isSelected ? "default" : "outline"}
                    size="sm"
                    onClick={() => toggleIndustry(industry)}
                    className="rounded-full"
                    disabled={!isSelected && selectedIndustries.length >= 3}
                    data-testid={`button-industry-${industry.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {industry}
                  </Button>
                );
              })}
            </div>

            <Card className="p-6 space-y-6">
              <div className="flex items-center gap-2 text-primary font-semibold">
                <MapPin className="w-4 h-4" />
                Travel Distance
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Location</Label>
                  <Input 
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Brisbane, QLD"
                    className="rounded-xl"
                    data-testid="input-location"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Max Distance: {radiusKm}km</Label>
                  <Slider
                    value={[radiusKm]}
                    onValueChange={([val]) => setRadiusKm(val)}
                    min={5}
                    max={50}
                    step={5}
                    className="py-4"
                    data-testid="slider-radius"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>5km</span>
                    <span>50km</span>
                  </div>
                </div>
              </div>

              <div className="h-32 bg-muted/30 rounded-xl border border-border/50 flex items-center justify-center relative overflow-hidden">
                <div className="absolute w-4 h-4 rounded-full bg-destructive border-2 border-white" style={{ left: "50%", top: "50%" }} />
                <div className="absolute w-2 h-2 rounded-full bg-green-500" style={{ left: "30%", top: "30%" }} />
                <div className="absolute w-2 h-2 rounded-full bg-green-500" style={{ left: "60%", top: "35%" }} />
                <div className="absolute w-2 h-2 rounded-full bg-green-500" style={{ left: "55%", top: "55%" }} />
                <div className="absolute w-2 h-2 rounded-full bg-green-500" style={{ left: "10%", top: "80%" }} />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Minimum Salary</Label>
                  <Input 
                    type="number"
                    value={salaryMin}
                    onChange={(e) => setSalaryMin(Number(e.target.value))}
                    className="rounded-xl"
                    data-testid="input-salary"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Employment Type</Label>
                  <Select value={employmentType} onValueChange={setEmploymentType}>
                    <SelectTrigger className="rounded-xl" data-testid="select-employment-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="full-time">Full-time</SelectItem>
                      <SelectItem value="part-time">Part-time</SelectItem>
                      <SelectItem value="casual">Casual</SelectItem>
                      <SelectItem value="contract">Contract</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </Card>

            <Card className="p-6 space-y-4">
              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-500 font-semibold">
                <Zap className="w-4 h-4" />
                AUTO MODE Settings
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="autoMode"
                  checked={autoMode}
                  onCheckedChange={(checked) => setAutoMode(checked as boolean)}
                  data-testid="checkbox-auto-mode"
                />
                <Label htmlFor="autoMode" className="font-medium">Enable AUTO MODE</Label>
              </div>

              {autoMode && (
                <>
                  <div className="space-y-2">
                    <Label>Applications Per Day</Label>
                    <Select value={String(dailyLimit)} onValueChange={(v) => setDailyLimit(Number(v))}>
                      <SelectTrigger className="rounded-xl" data-testid="select-daily-limit">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3">3 per day</SelectItem>
                        <SelectItem value="5">5 per day (Recommended)</SelectItem>
                        <SelectItem value="10">10 per day</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Safe limit to avoid spam flags</p>
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <span className="text-muted-foreground">Email for Notifications</span>
                    </Label>
                    <Input 
                      value={notificationEmail}
                      onChange={(e) => setNotificationEmail(e.target.value)}
                      placeholder="your@email.com"
                      type="email"
                      className="rounded-xl"
                      data-testid="input-notification-email"
                    />
                    <p className="text-xs text-muted-foreground">Get email confirmation for each application</p>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="weeklyMode"
                      checked={weeklyMode}
                      onCheckedChange={(checked) => setWeeklyMode(checked as boolean)}
                      data-testid="checkbox-weekly-mode"
                    />
                    <Label htmlFor="weeklyMode" className="font-medium flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Weekly Mode (Auto-run for 7 days)
                    </Label>
                  </div>

                  {weeklyMode && (
                    <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg text-sm space-y-1">
                      <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                        <CheckCircle2 className="w-4 h-4" />
                        App will auto-apply to {dailyLimit} jobs per day for 7 days
                      </div>
                      <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                        <CheckCircle2 className="w-4 h-4" />
                        Daily email summaries sent to {notificationEmail || "your email"}
                      </div>
                      <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                        <CheckCircle2 className="w-4 h-4" />
                        Re-activate next week with one click
                      </div>
                    </div>
                  )}
                </>
              )}
            </Card>

            <Button 
              onClick={saveStep2AndGenerate}
              disabled={isSaving || isGenerating || demoGenerating || selectedIndustries.length !== 3}
              className="w-full h-14 rounded-xl text-lg gap-2"
              data-testid="button-continue-step2"
            >
              {(isSaving || isGenerating || demoGenerating) ? <Loader2 className="w-5 h-5 animate-spin" /> : null}
              {(isGenerating || demoGenerating) ? "Generating Tailored Resumes..." : "Generate Tailored Resumes"}
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-6">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="font-display font-bold text-2xl mb-2">Step 3: Review Tailored Resumes</h2>
                <p className="text-muted-foreground">Your resumes have been optimized for each industry.</p>
              </div>
            </div>

            {resumesLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : resumes && resumes.length > 0 ? (
              <div className="space-y-4">
                {resumes.map((resume) => (
                  <Card key={resume.id} className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="font-display font-bold text-xl text-primary capitalize">
                        {resume.industry}
                      </h3>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            variant="default" 
                            className="gap-2 rounded-xl"
                            onClick={() => {
                              setEditingResume(resume);
                              setEditContent(resume.content);
                            }}
                            data-testid={`button-edit-resume-${resume.id}`}
                          >
                            <Pencil className="w-4 h-4" /> Edit
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-3xl max-h-[80vh]">
                          <DialogHeader>
                            <DialogTitle className="capitalize">{resume.industry} Resume</DialogTitle>
                          </DialogHeader>
                          <Textarea 
                            value={editContent}
                            onChange={(e) => setEditContent(e.target.value)}
                            className="min-h-[400px] font-mono text-sm"
                          />
                          <div className="flex justify-end gap-2">
                            <Button 
                              onClick={handleSaveResume}
                              disabled={isUpdatingResume}
                              data-testid="button-save-resume"
                            >
                              {isUpdatingResume ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                              Save Changes
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                    <div className="bg-muted/30 rounded-xl p-4 text-sm">
                      <p className="uppercase text-xs font-semibold text-muted-foreground mb-2">
                        TAILORED RESUME - {resume.industry.toUpperCase()}
                      </p>
                      <p className="line-clamp-4 whitespace-pre-wrap">{resume.content}</p>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">No resumes generated yet.</p>
              </Card>
            )}

            <Button 
              onClick={() => setCurrentStep(4)}
              disabled={!resumes || resumes.length === 0}
              className="w-full h-14 rounded-xl text-lg gap-2"
              data-testid="button-continue-step3"
            >
              Continue to Find Jobs
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        )}

        {currentStep === 4 && (
          <div className="space-y-6">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="font-display font-bold text-2xl mb-2">Step 4: Matched Jobs</h2>
                <p className="text-muted-foreground">Jobs within {radiusKm}km</p>
              </div>
              {unappliedCount > 0 && (
                <Button 
                  onClick={handleAutoApply}
                  disabled={isAutoApplying}
                  className="gap-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl"
                  data-testid="button-auto-apply"
                >
                  {isAutoApplying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                  Auto-Apply ({Math.min(unappliedCount, dailyLimit)} jobs)
                </Button>
              )}
            </div>

            {jobsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : jobs && jobs.length > 0 ? (
              <div className="space-y-4">
                {jobs.map((job) => {
                  const isApplied = appliedJobIds.has(job.id);
                  const matchScore = job.matchScore || Math.floor(Math.random() * 15) + 85;
                  const matchingResume = resumes?.find(r => 
                    r.industry.toLowerCase() === job.industry?.toLowerCase()
                  );
                  
                  return (
                    <Card key={job.id} className="p-6">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="font-display font-bold text-lg">{job.title}</h3>
                          <p className="text-muted-foreground">{job.company} - {job.location}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-green-600 dark:text-green-400 font-bold">{matchScore}% Match</div>
                          <div className="text-xs text-muted-foreground">
                            {job.postedAt ? formatDistanceToNow(new Date(job.postedAt), { addSuffix: true }) : "Recently"}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                        <MapPin className="w-4 h-4" />
                        <span>~{Math.floor(Math.random() * radiusKm) + 1}km from home</span>
                      </div>

                      {job.description && (
                        <p className="text-sm mb-4 line-clamp-2">{job.description}</p>
                      )}

                      <div className="flex flex-wrap gap-2 mb-4">
                        <Badge variant="outline">{job.source || "Seek"}</Badge>
                        {job.salary && <Badge variant="outline">${(job.salary / 1000).toFixed(0)}k</Badge>}
                        <Badge variant="outline">{job.type || "Full-time"}</Badge>
                      </div>

                      {matchingResume && (
                        <p className="text-xs text-muted-foreground mb-4">
                          Resume: <span className="text-primary font-medium">{matchingResume.industry}</span> - Cover letter auto-personalized for {job.company}
                        </p>
                      )}

                      <div className="flex justify-end">
                        <Button
                          onClick={() => handleApply(job.id)}
                          disabled={isApplied || isApplying}
                          variant={isApplied ? "secondary" : "default"}
                          className="gap-2 rounded-xl"
                          data-testid={`button-apply-${job.id}`}
                        >
                          {isApplied ? (
                            <>
                              <CheckCircle2 className="w-4 h-4" /> Applied
                            </>
                          ) : (
                            <>
                              <Send className="w-4 h-4" /> Apply Now
                            </>
                          )}
                        </Button>
                      </div>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">No matching jobs found. Try adjusting your preferences.</p>
              </Card>
            )}

            <Button 
              onClick={() => setCurrentStep(5)}
              className="w-full h-14 rounded-xl text-lg gap-2"
              data-testid="button-continue-step4"
            >
              Continue to Track Applications
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        )}

        {currentStep === 5 && (() => {
          const totalApps = applications?.length || 0;
          const todayApps = applications?.filter(a => {
            if (!a.appliedAt) return false;
            const today = new Date();
            const appDate = new Date(a.appliedAt);
            return appDate.toDateString() === today.toDateString();
          }).length || 0;
          const autoApps = applications?.filter(a => a.autoApplied).length || 0;
          const avgMatch = totalApps > 0 
            ? Math.round(applications!.reduce((sum, a) => sum + (a.matchScore || 75), 0) / totalApps)
            : 0;

          const generateReportText = () => {
            if (!applications || applications.length === 0) return "";
            let report = "WORKFORCE AUSTRALIA JOB APPLICATION REPORT\n";
            report += "Generated: " + format(new Date(), "dd/MM/yyyy HH:mm") + "\n";
            report += "=".repeat(50) + "\n\n";
            
            applications.forEach((app, idx) => {
              const appDate = app.appliedAt ? format(new Date(app.appliedAt), "dd/MM/yyyy") : "N/A";
              const appTime = app.appliedAt ? format(new Date(app.appliedAt), "HH:mm") : "";
              report += `${idx + 1}. ${app.jobTitle || "Position"}\n`;
              report += `   Company: ${app.company || "N/A"}\n`;
              report += `   Location: ${app.location || "N/A"}\n`;
              report += `   Applied: ${appDate} ${appTime}\n`;
              report += `   Source: ${app.source || "Job Board"}\n`;
              report += `   Status: ${app.status || "Applied"}\n\n`;
            });
            
            report += "=".repeat(50) + "\n";
            report += `Total Applications: ${totalApps}\n`;
            report += `Auto-Applied: ${autoApps}\n`;
            report += `Average Match: ${avgMatch}%\n`;
            
            return report;
          };

          const copyReport = () => {
            const report = generateReportText();
            navigator.clipboard.writeText(report);
            toast({ title: "Copied!", description: "Report copied to clipboard for Workforce Australia." });
          };

          const downloadPDF = () => {
            const report = generateReportText();
            const blob = new Blob([report], { type: "text/plain" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `workforce-australia-report-${format(new Date(), "yyyy-MM-dd")}.txt`;
            a.click();
            URL.revokeObjectURL(url);
            toast({ title: "Downloaded!", description: "Report saved for Workforce Australia submission." });
          };

          return (
          <div className="space-y-6">
            <div>
              <h2 className="font-display font-bold text-2xl mb-2">Step 5: Application Tracker</h2>
              <p className="text-muted-foreground">All applications ready for Workforce Australia</p>
            </div>

            <Card className="p-6">
              <div className="grid grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-3xl font-bold text-primary">{totalApps}</div>
                  <div className="text-sm text-muted-foreground">Total</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-muted-foreground">{todayApps}</div>
                  <div className="text-sm text-muted-foreground">Today</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">{autoApps}</div>
                  <div className="text-sm text-muted-foreground">Auto</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-amber-500">{avgMatch}%</div>
                  <div className="text-sm text-muted-foreground">Avg Match</div>
                </div>
              </div>
            </Card>

            {notificationEmail && applications && applications.length > 0 && (
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Bell className="w-5 h-5 text-amber-500" />
                  <span className="font-semibold">Email Notifications ({applications.length})</span>
                </div>
                <div className="bg-muted/50 rounded-lg p-3 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <span>To: {notificationEmail}</span>
                    {applications[0]?.appliedAt && (
                      <span className="ml-auto">{format(new Date(applications[0].appliedAt), "dd/MM/yyyy, HH:mm:ss")}</span>
                    )}
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <span>
                      QuotaFlow: Applied to {applications[0]?.jobTitle} at {applications[0]?.company} ({applications[0]?.source || "Job Board"}). Resume: {applications[0]?.resumeUsed || "General"}.
                    </span>
                  </div>
                  <span className="text-green-600 text-xs ml-6">sent</span>
                </div>
              </Card>
            )}

            <div className="flex gap-2">
              <Button 
                variant={applicationFilter === "all" ? "default" : "outline"} 
                size="sm"
                onClick={() => setApplicationFilter("all")}
                data-testid="button-filter-all"
              >
                All ({applications?.length || 0})
              </Button>
              <Button 
                variant={applicationFilter === "auto" ? "default" : "outline"} 
                size="sm"
                onClick={() => setApplicationFilter("auto")}
                className="gap-1"
                data-testid="button-filter-auto"
              >
                <Zap className="w-3 h-3" />
                Auto-Applied ({applications?.filter(a => a.autoApplied).length || 0})
              </Button>
              <Button 
                variant={applicationFilter === "manual" ? "default" : "outline"} 
                size="sm"
                onClick={() => setApplicationFilter("manual")}
                data-testid="button-filter-manual"
              >
                Manual ({applications?.filter(a => !a.autoApplied).length || 0})
              </Button>
            </div>

            {applications && applications.length > 0 ? (
              <div className="space-y-3">
                {applications
                  .filter(app => {
                    if (applicationFilter === "auto") return app.autoApplied;
                    if (applicationFilter === "manual") return !app.autoApplied;
                    return true;
                  })
                  .map((app, idx) => {
                  const appDate = app.appliedAt ? format(new Date(app.appliedAt), "dd/MM/yyyy") : "";
                  const appTime = app.appliedAt ? format(new Date(app.appliedAt), "h:mm a") : "";
                  const matchScore = app.matchScore || 75;
                  
                  return (
                    <Card key={app.id} className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-bold">{idx + 1}. {app.jobTitle}</span>
                          {app.autoApplied && (
                            <Badge className="bg-amber-500 text-white text-xs">
                              <Zap className="w-3 h-3 mr-1" /> AUTO
                            </Badge>
                          )}
                        </div>
                        <div className="text-right text-sm text-muted-foreground">
                          <div>{appDate}</div>
                          <div>{appTime}</div>
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground mb-2">{app.company}</div>
                      <div className="flex items-center gap-1 text-sm text-primary mb-3">
                        <MapPin className="w-4 h-4" />
                        {app.location}
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="outline">{app.source || "Seek"}</Badge>
                        <Badge variant="outline">{app.resumeUsed || "General"}</Badge>
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          {matchScore}% match
                        </Badge>
                      </div>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">No applications yet. Go back to step 4 to apply for jobs.</p>
              </Card>
            )}

            <div className="flex gap-4">
              <Button 
                onClick={() => setCurrentStep(4)}
                variant="outline"
                className="flex-1 h-14 rounded-xl text-lg gap-2"
                data-testid="button-back-jobs"
              >
                <ArrowLeft className="w-5 h-5" />
                Back to Jobs
              </Button>
              <Button 
                onClick={copyReport}
                disabled={!applications || applications.length === 0}
                className="flex-1 h-14 rounded-xl text-lg gap-2 bg-green-600 hover:bg-green-700 text-white"
                data-testid="button-copy-report"
              >
                <Copy className="w-5 h-5" />
                Copy Report for Workforce Australia
              </Button>
            </div>

            <Button 
              onClick={downloadPDF}
              disabled={!applications || applications.length === 0}
              variant="outline"
              className="w-full h-12 rounded-xl gap-2"
              data-testid="button-download-report"
            >
              <Download className="w-5 h-5" />
              Download Report as File
            </Button>
          </div>
          );
        })()}
      </div>
    </div>
  );
}
