import { Sidebar } from "@/components/Sidebar";
import { useApplications } from "@/hooks/use-applications";
import { Loader2, FileText, Calendar, Building2, ExternalLink, Copy, Check, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Applications() {
  const { data: applications, isLoading } = useApplications();
  const [copied, setCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'applied': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'interviewing': return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
      case 'rejected': return 'bg-red-500/10 text-red-600 border-red-500/20';
      case 'offered': return 'bg-green-500/10 text-green-600 border-green-500/20';
      default: return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
    }
  };

  const handleExportReport = async () => {
    setIsExporting(true);
    try {
      const response = await apiRequest('GET', '/api/applications/report');
      const data = await response.json();
      
      await navigator.clipboard.writeText(data.report);
      setCopied(true);
      
      toast({
        title: "Report copied!",
        description: "Your Workforce Australia report has been copied to clipboard.",
      });

      setTimeout(() => setCopied(false), 3000);
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Could not generate report. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadReport = async () => {
    setIsExporting(true);
    try {
      const response = await apiRequest('GET', '/api/applications/report');
      const data = await response.json();
      
      const blob = new Blob([data.report], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `QuotaFlow_Report_${new Date().toISOString().split('T')[0]}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Report downloaded!",
        description: "Your Workforce Australia report has been saved.",
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Could not download report. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-background font-body">
      <Sidebar />
      <div className="flex-1 ml-0 md:ml-64 p-4 md:p-8">
        <header className="mb-8 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="font-display font-bold text-2xl md:text-3xl mb-2">Application History</h1>
            <p className="text-muted-foreground text-sm md:text-base">Track and manage your submitted applications.</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button 
              variant="outline" 
              className="gap-2 rounded-xl"
              onClick={handleExportReport}
              disabled={isExporting}
              data-testid="button-copy-report"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Copied!' : 'Copy Report'}
            </Button>
            <Button 
              variant="default" 
              className="gap-2 rounded-xl"
              onClick={handleDownloadReport}
              disabled={isExporting}
              data-testid="button-download-report"
            >
              <Download className="w-4 h-4" />
              Download
            </Button>
          </div>
        </header>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* Mobile Cards View */}
            <div className="md:hidden space-y-4">
              {applications?.map((app) => (
                <div key={app.id} className="bg-card border border-border/50 rounded-xl p-4 shadow-sm" data-testid={`card-application-${app.id}`}>
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-semibold">{app.jobTitle || app.job?.title || "Unknown Role"}</h3>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        <Building2 className="w-3 h-3" />
                        {app.company || app.job?.company || "Unknown Company"}
                      </p>
                    </div>
                    <span className={cn("px-2 py-1 rounded-full text-xs font-semibold border capitalize", getStatusColor(app.status || 'applied'))}>
                      {app.status}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {app.appliedAt ? new Date(app.appliedAt).toLocaleDateString() : '-'}
                    </span>
                    <span className="bg-muted/50 px-2 py-0.5 rounded text-xs">
                      {app.resumeUsed || "Standard"}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block bg-card border border-border/50 rounded-2xl overflow-hidden shadow-sm">
              <table className="w-full">
                <thead className="bg-muted/30 border-b border-border/50">
                  <tr>
                    <th className="text-left py-4 px-6 font-medium text-muted-foreground text-sm">Role & Company</th>
                    <th className="text-left py-4 px-6 font-medium text-muted-foreground text-sm">Applied Date</th>
                    <th className="text-left py-4 px-6 font-medium text-muted-foreground text-sm">Status</th>
                    <th className="text-left py-4 px-6 font-medium text-muted-foreground text-sm">Resume Used</th>
                    <th className="text-right py-4 px-6 font-medium text-muted-foreground text-sm">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {applications?.map((app) => (
                    <tr key={app.id} className="border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors" data-testid={`row-application-${app.id}`}>
                      <td className="py-4 px-6">
                        <div className="font-semibold text-foreground">{app.jobTitle || app.job?.title || "Unknown Role"}</div>
                        <div className="flex items-center gap-1.5 text-sm text-muted-foreground mt-0.5">
                          <Building2 className="w-3 h-3" />
                          {app.company || app.job?.company || "Unknown Company"}
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="w-4 h-4" />
                          {app.appliedAt ? new Date(app.appliedAt).toLocaleDateString() : '-'}
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span className={cn("px-3 py-1 rounded-full text-xs font-semibold border capitalize", getStatusColor(app.status || 'applied'))}>
                          {app.status}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <span className="text-sm text-muted-foreground bg-muted/50 px-2 py-1 rounded-md border border-border/50">
                          {app.resumeUsed || "Standard"}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-right">
                        <Button variant="ghost" size="icon" data-testid={`button-view-${app.id}`}>
                          <ExternalLink className="w-4 h-4 text-muted-foreground" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              
              {(!applications || applications.length === 0) && (
                <div className="p-12 text-center text-muted-foreground">
                  No applications found. Head to the Jobs page to start applying!
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
