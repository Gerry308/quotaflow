import { Sidebar } from "@/components/Sidebar";
import { usePreferences, useUpdatePreferences } from "@/hooks/use-preferences";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Loader2, Save, X, Target, Zap, MapPin } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserProfileSchema } from "@shared/schema";
import { z } from "zod";
import { useEffect, useState } from "react";

const AVAILABLE_INDUSTRIES = [
  "Retail & Customer Service",
  "Warehouse & Logistics",
  "Administration & Office",
  "Health & Fitness",
  "Hospitality & Food Service",
  "Construction & Trades",
  "IT & Technology",
  "Sales & Marketing",
];

const formSchema = insertUserProfileSchema.omit({ userId: true });
type FormData = z.infer<typeof formSchema>;

export default function Profile() {
  const { data: preferences, isLoading } = usePreferences();
  const { mutate: update, isPending: isSaving } = useUpdatePreferences();
  const [selectedIndustries, setSelectedIndustries] = useState<string[]>([]);

  const { register, handleSubmit, reset, setValue, watch } = useForm<FormData>({
    resolver: zodResolver(formSchema.partial()),
  });

  useEffect(() => {
    if (preferences) {
      reset(preferences);
      setSelectedIndustries(preferences.industries || []);
    }
  }, [preferences, reset]);

  const toggleIndustry = (industry: string) => {
    let newIndustries: string[];
    if (selectedIndustries.includes(industry)) {
      newIndustries = selectedIndustries.filter(i => i !== industry);
    } else if (selectedIndustries.length < 3) {
      newIndustries = [...selectedIndustries, industry];
    } else {
      return;
    }
    setSelectedIndustries(newIndustries);
    setValue("industries", newIndustries);
  };

  const onSubmit = (data: FormData) => {
    update({ ...data, industries: selectedIndustries });
  };

  return (
    <div className="flex min-h-screen bg-background font-body">
      <Sidebar />
      <div className="flex-1 ml-0 md:ml-64 p-4 md:p-8">
        <header className="mb-6 md:mb-8">
          <h1 className="font-display font-bold text-2xl md:text-3xl mb-2">Profile & Preferences</h1>
          <p className="text-muted-foreground text-sm md:text-base">Configure your job search parameters and automation settings.</p>
        </header>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="max-w-4xl space-y-8">
            <div className="bg-card border border-border/50 rounded-2xl p-6 shadow-sm">
              <h3 className="font-display font-bold text-xl mb-6 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                  <Target className="w-4 h-4" />
                </div>
                Target Industries
              </h3>
              <p className="text-muted-foreground text-sm mb-4">
                Select up to 3 industries. We'll generate tailored resumes for each.
              </p>
              <div className="flex flex-wrap gap-2 mb-4">
                {AVAILABLE_INDUSTRIES.map((industry) => {
                  const isSelected = selectedIndustries.includes(industry);
                  return (
                    <Button
                      key={industry}
                      type="button"
                      variant={isSelected ? "default" : "outline"}
                      size="sm"
                      onClick={() => toggleIndustry(industry)}
                      className={`rounded-full ${isSelected ? "bg-primary" : ""}`}
                      disabled={!isSelected && selectedIndustries.length >= 3}
                      data-testid={`button-industry-${industry.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      {industry}
                      {isSelected && <X className="w-3 h-3 ml-1" />}
                    </Button>
                  );
                })}
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{selectedIndustries.length}/3 selected</Badge>
              </div>
            </div>

            <div className="bg-card border border-border/50 rounded-2xl p-6 shadow-sm">
              <h3 className="font-display font-bold text-xl mb-6 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-accent/10 text-accent-foreground flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                Automation Settings
              </h3>
              
              <div className="grid md:grid-cols-2 gap-8">
                <div className="flex items-center justify-between p-4 border border-border/50 rounded-xl bg-muted/20">
                  <div className="space-y-0.5">
                    <Label className="text-base font-semibold">Auto-Apply Mode</Label>
                    <p className="text-sm text-muted-foreground">Automatically submit applications</p>
                  </div>
                  <Switch 
                    checked={watch("autoMode") || false}
                    onCheckedChange={(checked) => setValue("autoMode", checked)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Daily Application Limit</Label>
                  <Input 
                    type="number" 
                    {...register("dailyLimit", { valueAsNumber: true })}
                    className="rounded-xl border-border/50 bg-background"
                  />
                  <p className="text-xs text-muted-foreground">Maximum applications per day.</p>
                </div>
              </div>
            </div>

            <div className="bg-card border border-border/50 rounded-2xl p-6 shadow-sm">
              <h3 className="font-display font-bold text-xl mb-6 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-green-500/10 text-green-600 flex items-center justify-center">
                  <MapPin className="w-4 h-4" />
                </div>
                Location & Salary
              </h3>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Location</Label>
                  <Input 
                    {...register("location")}
                    placeholder="e.g. Brisbane, QLD"
                    className="rounded-xl border-border/50 bg-background"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Search Radius (km)</Label>
                  <Input 
                    type="number"
                    {...register("radiusKm", { valueAsNumber: true })}
                    className="rounded-xl border-border/50 bg-background"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Minimum Salary</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                    <Input 
                      type="number"
                      {...register("salaryMin", { valueAsNumber: true })}
                      className="pl-8 rounded-xl border-border/50 bg-background"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <Button 
                type="submit" 
                disabled={isSaving}
                size="lg"
                className="rounded-xl px-8 shadow-lg shadow-primary/20"
              >
                {isSaving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                Save Changes
              </Button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
