import { Sidebar } from "@/components/Sidebar";
import { useJobs } from "@/hooks/use-jobs";
import { useCreateApplication } from "@/hooks/use-applications";
import { useApplications } from "@/hooks/use-applications";
import { JobCard } from "@/components/JobCard";
import { Button } from "@/components/ui/button";
import { Loader2, Search, SlidersHorizontal, RefreshCcw } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";

export default function Jobs() {
  const [isScanning, setIsScanning] = useState(false);
  const { data: jobs, isLoading, refetch } = useJobs(isScanning);
  const { data: applications } = useApplications();
  const { mutate: apply, isPending: isApplying } = useCreateApplication();
  const [search, setSearch] = useState("");

  const handleScan = async () => {
    setIsScanning(true);
    await refetch();
    setIsScanning(false);
  };

  const filteredJobs = jobs?.filter(job => 
    job.title.toLowerCase().includes(search.toLowerCase()) || 
    job.company.toLowerCase().includes(search.toLowerCase())
  ) || [];

  return (
    <div className="flex min-h-screen bg-background font-body">
      <Sidebar />
      <div className="flex-1 ml-0 md:ml-64 p-4 md:p-8">
        <header className="mb-6 md:mb-8">
          <h1 className="font-display font-bold text-2xl md:text-3xl mb-2">Find Jobs</h1>
          <p className="text-muted-foreground text-sm md:text-base">AI-curated opportunities matching your profile.</p>
        </header>

        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input 
              placeholder="Search by title, company, or keyword..." 
              className="pl-10 h-12 rounded-xl bg-card border-border/50 focus:ring-primary/20"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Button variant="outline" className="h-12 rounded-xl border-border/50 gap-2">
            <SlidersHorizontal className="w-4 h-4" /> Filters
          </Button>
          <Button 
            onClick={handleScan}
            disabled={isScanning}
            className="h-12 rounded-xl gap-2 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20"
          >
            {isScanning ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <RefreshCcw className="w-4 h-4" />
            )}
            {isScanning ? "Scanning..." : "Scan New Jobs"}
          </Button>
        </div>

        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
            <Loader2 className="w-10 h-10 animate-spin text-primary mb-4" />
            <p>Finding the best matches for you...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredJobs.length > 0 ? (
              filteredJobs.map(job => (
                <JobCard 
                  key={job.id} 
                  job={job} 
                  onApply={(id) => apply({ jobId: id, matchScore: job.matchScore })}
                  isApplied={applications?.some(a => a.jobId === job.id)}
                  isApplying={isApplying}
                />
              ))
            ) : (
              <div className="col-span-full text-center py-20 text-muted-foreground">
                No jobs found matching your criteria. Try scanning for new ones!
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
