import { ArrowRight, Zap, FileText, CheckCircle, Star, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Navigation */}
      <nav className="absolute w-full z-50 px-6 py-4">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <span className="font-bold text-xl text-white">QuotaFlow</span>
          <a href="/api/login">
            <Button variant="ghost" className="text-white hover:bg-white/10" data-testid="button-login">
              Log In
            </Button>
          </a>
        </div>
      </nav>

      {/* Hero Section - Purple Gradient */}
      <section className="relative bg-gradient-to-br from-indigo-600 via-purple-600 to-indigo-800 pt-32 pb-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
            Your job search <span className="text-yellow-400">on Autopilot.</span>
          </h1>
          <p className="text-lg md:text-xl text-white/80 mb-10 max-w-2xl mx-auto">
            QuotaFlow automatically searches and applies for jobs for you every day. Just set it and forget it!
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="/api/login">
              <Button 
                size="lg" 
                className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 font-semibold rounded-full px-8 h-14 text-lg shadow-lg"
                data-testid="button-get-started"
              >
                Get Started <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </a>
            <a href="/demo">
              <Button 
                size="lg" 
                variant="outline"
                className="border-white/50 text-white rounded-full px-8 h-14 text-lg backdrop-blur-sm bg-white/10"
                data-testid="button-demo"
              >
                Try Demo
              </Button>
            </a>
          </div>
          
          {/* Social proof */}
          <div className="flex items-center justify-center gap-3 mt-10">
            <div className="flex -space-x-2">
              <div className="w-8 h-8 rounded-full bg-indigo-400" />
              <div className="w-8 h-8 rounded-full bg-purple-400" />
              <div className="w-8 h-8 rounded-full bg-cyan-400" />
            </div>
            <span className="text-white/80 text-sm font-medium">Trusted by <strong className="text-white">500+ Jobseekers</strong></span>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-slate-50 dark:bg-slate-900">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Hit Your Centrelink Quota. <span className="text-indigo-600">No Stress.</span>
          </h2>
          
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            {/* Auto-Apply Daily */}
            <Card className="p-6 bg-indigo-50 dark:bg-indigo-950/30 border-0">
              <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-lg mb-2">Auto-Apply Daily</h3>
              <p className="text-muted-foreground">Apply to 5 jobs per day automatically. Hit your 20 applications in 4 days.</p>
            </Card>
            
            {/* AI Tailored Resumes */}
            <Card className="p-6 bg-pink-50 dark:bg-pink-950/30 border-0">
              <div className="w-12 h-12 rounded-xl bg-purple-600 flex items-center justify-center mb-4">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-lg mb-2">AI Tailored Resumes</h3>
              <p className="text-muted-foreground">Upload once. AI creates 3 industry-specific versions perfectly matched.</p>
            </Card>
            
            {/* One-Click Reporting */}
            <Card className="p-6 bg-green-50 dark:bg-green-950/30 border-0">
              <div className="w-12 h-12 rounded-xl bg-green-600 flex items-center justify-center mb-4">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-lg mb-2">One-Click Reporting</h3>
              <p className="text-muted-foreground">Copy perfect Workforce Australia reports. No typing. Just paste.</p>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works - Set Up in 5 Minutes */}
      <section className="py-20 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-16">
            Set Up in <span className="text-indigo-600">5 Minutes</span>
          </h2>
          
          <div className="space-y-12">
            {[
              { num: 1, title: "Upload Resume", desc: "Paste your resume and cover letter template", color: "bg-indigo-600" },
              { num: 2, title: "Pick Industries", desc: "Select 3 industries you want to work in", color: "bg-pink-500" },
              { num: 3, title: "Set Preferences", desc: "Distance, salary, and how many jobs per day", color: "bg-green-500" },
              { num: 4, title: "Review AI Resumes", desc: "Check the tailored versions for each industry", color: "bg-orange-500" },
              { num: 5, title: "Sit Back & Relax", desc: "We handle the applications, you focus on interviews", color: "bg-cyan-500" }
            ].map((step) => (
              <div key={step.num} className="flex flex-col items-center">
                <div className={`w-14 h-14 rounded-full ${step.color} flex items-center justify-center text-white text-xl font-bold mb-4`}>
                  {step.num}
                </div>
                <h3 className="font-bold text-xl mb-2">{step.title}</h3>
                <p className="text-muted-foreground">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-6 bg-slate-50 dark:bg-slate-900">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">What People Say</h2>
          
          <div className="space-y-6">
            <Card className="p-6 border-0 shadow-sm">
              <div className="flex items-start gap-4">
                <Avatar className="w-12 h-12">
                  <AvatarFallback className="bg-indigo-600 text-white">SM</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h4 className="font-bold">Sarah M.</h4>
                  <p className="text-sm text-muted-foreground mb-3">Brisbane JobSeeker</p>
                  <p className="text-muted-foreground italic">
                    "I used to stress every month about hitting 20 applications. Now I hit my quota in the first week and spend the rest finding work I actually want. Game changer."
                  </p>
                  <div className="flex gap-1 mt-3">
                    {[1,2,3,4,5].map(i => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </div>
              </div>
            </Card>
            
            <Card className="p-6 border-0 shadow-sm bg-green-50/50 dark:bg-green-950/20">
              <div className="flex items-start gap-4">
                <Avatar className="w-12 h-12">
                  <AvatarFallback className="bg-green-600 text-white">DK</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h4 className="font-bold">David K.</h4>
                  <p className="text-sm text-muted-foreground mb-3">Melbourne JobSeeker</p>
                  <p className="text-muted-foreground italic">
                    "My job provider loves the reports. So clean and professional. And the auto-apply saved me hours every week. Worth way more than $2."
                  </p>
                  <div className="flex gap-1 mt-3">
                    {[1,2,3,4,5].map(i => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Progress Tracking Demo */}
      <section className="py-20 px-6 bg-gradient-to-br from-indigo-600 via-purple-600 to-indigo-800">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Track Your Progress in Real-Time</h2>
          <p className="text-white/80 mb-12">Visual progress bar shows exactly where you are toward your monthly quota</p>
          
          <Card className="p-6 max-w-lg mx-auto">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-indigo-600" />
                <span className="font-semibold">Centrelink Compliance Meter</span>
              </div>
              <span className="text-sm text-muted-foreground">20 applications required</span>
            </div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl font-bold text-indigo-600">15/20</span>
              <span className="text-sm text-muted-foreground">5 more needed</span>
            </div>
            <div className="relative mb-4">
              <Progress value={75} className="h-4" />
              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-medium text-white">75%</span>
            </div>
            <div className="flex gap-4 text-sm">
              <label className="flex items-center gap-2">
                <input type="checkbox" checked readOnly className="rounded text-indigo-600" />
                <span>10 Auto-Applied</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" checked readOnly className="rounded text-green-600" />
                <span>5 Manual</span>
              </label>
            </div>
          </Card>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Simple Pricing. <span className="text-indigo-600">No Surprises.</span>
          </h2>
          <p className="text-muted-foreground mb-12">Less than a coffee. Cancel anytime.</p>
          
          <Card className="p-8 max-w-md mx-auto border-2 border-indigo-100 dark:border-indigo-900">
            <div className="text-5xl font-bold text-indigo-600 mb-2">$2</div>
            <p className="text-muted-foreground mb-8">per month</p>
            
            <ul className="space-y-4 text-left mb-8">
              {[
                "Auto-apply to 20-30 jobs/month",
                "AI-tailored resumes (3 industries)",
                "Personalized cover letters",
                "SMS notifications",
                "Workforce Australia reports",
                "Duplicate prevention",
                "Distance & salary filters",
                "Progress tracking"
              ].map((feature, i) => (
                <li key={i} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            
            <a href="/api/login">
              <Button className="w-full h-12 text-lg font-semibold" data-testid="button-start-trial">
                Start Free Trial
              </Button>
            </a>
          </Card>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 px-6 bg-gradient-to-br from-indigo-600 via-purple-600 to-indigo-800">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Stop Stressing. <span className="text-yellow-400">Start Applying.</span>
          </h2>
          <p className="text-white/80 text-lg mb-10">Join 500+ Aussies who've taken back their time</p>
          
          <a href="/api/login">
            <Button 
              size="lg" 
              className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 font-semibold rounded-full px-10 h-14 text-lg shadow-lg"
              data-testid="button-get-started-free"
            >
              Get Started Free <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 bg-slate-900 text-slate-400">
        <div className="max-w-4xl mx-auto text-center">
          <p className="mb-4">2025 QuotaFlow. Built for Aussie JobSeekers. Centrelink compliant.</p>
          <div className="flex justify-center gap-6 text-sm">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
