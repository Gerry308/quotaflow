import { Sidebar } from "@/components/Sidebar";
import { useResumes, useGenerateResumes } from "@/hooks/use-resumes";
import { usePreferences, useUpdatePreferences } from "@/hooks/use-preferences";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Loader2, Wand2, FileText, Download, Eye, AlertTriangle } from "lucide-react";
import { useState, useEffect } from "react";
import { Link } from "wouter";

export default function Resumes() {
  const { data: resumes, isLoading: resumesLoading } = useResumes();
  const { data: preferences, isLoading: preferencesLoading } = usePreferences();
  const { mutate: updatePreferences, isPending: isSaving } = useUpdatePreferences();
  const { mutate: generate, isPending: isGenerating } = useGenerateResumes();

  const [baseResume, setBaseResume] = useState("");
  const [baseCoverLetter, setBaseCoverLetter] = useState("");

  useEffect(() => {
    if (preferences) {
      setBaseResume(preferences.baseResume || "");
      setBaseCoverLetter(preferences.baseCoverLetter || "");
    }
  }, [preferences]);

  const handleGenerate = () => {
    updatePreferences({
      baseResume,
      baseCoverLetter,
      industries: preferences?.industries || [],
    }, {
      onSuccess: () => {
        generate();
      }
    });
  };

  const handleDownload = (resume: any) => {
    const content = `${resume.industry.toUpperCase()} RESUME\n\n${resume.content}`;
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `resume-${resume.industry.toLowerCase().replace(/\s+/g, "-")}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const hasIndustries = (preferences?.industries?.length || 0) > 0;
  const hasBaseResume = baseResume.trim().length > 50;
  const canGenerate = hasBaseResume && hasIndustries;

  if (preferencesLoading) {
    return (
      <div className="flex min-h-screen bg-background font-body">
        <Sidebar />
        <div className="flex-1 ml-0 md:ml-64 flex items-center justify-center">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-background font-body">
      <Sidebar />
      <div className="flex-1 ml-0 md:ml-64 p-4 md:p-8">
        <header className="mb-6 md:mb-8 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="font-display font-bold text-2xl md:text-3xl mb-2">AI Tailored Resumes</h1>
            <p className="text-muted-foreground text-sm md:text-base">
              We automatically rewrite your resume for your selected industries.
            </p>
          </div>
          <Button 
            onClick={handleGenerate}
            disabled={isGenerating || isSaving || !canGenerate}
            className="h-12 rounded-xl gap-2 bg-primary hover:bg-primary/90 shadow-lg w-full sm:w-auto"
            data-testid="button-generate-resumes"
          >
            {(isGenerating || isSaving) ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
            {isSaving ? "Saving..." : isGenerating ? "Generating..." : "Generate New Versions"}
          </Button>
        </header>

        {!hasIndustries && (
          <div className="mb-6 p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-xl flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-500 flex-shrink-0" />
            <p className="text-yellow-800 dark:text-yellow-200 text-sm">
              Please select industries in your{" "}
              <Link href="/profile" className="underline font-medium">
                Profile
              </Link>{" "}
              to enable AI resume generation.
            </p>
          </div>
        )}

        <div className="space-y-6 mb-8">
          <div>
            <label className="block font-display font-bold text-lg mb-2">Base Resume Content</label>
            <Textarea
              value={baseResume}
              onChange={(e) => setBaseResume(e.target.value)}
              placeholder="Paste your resume text here..."
              className="min-h-[300px] resize-none text-sm"
              data-testid="textarea-base-resume"
            />
            {!hasBaseResume && baseResume.length > 0 && (
              <p className="text-xs text-muted-foreground mt-2">
                {baseResume.length} characters (minimum 50 required)
              </p>
            )}
          </div>

          <div>
            <label className="block font-display font-bold text-lg mb-2">Cover Letter Template</label>
            <Textarea
              value={baseCoverLetter}
              onChange={(e) => setBaseCoverLetter(e.target.value)}
              placeholder="Paste your cover letter template here..."
              className="min-h-[300px] resize-none text-sm"
              data-testid="textarea-cover-letter"
            />
          </div>
        </div>

        <div className="border-t border-border/50 pt-8">
          <h2 className="font-display font-bold text-xl mb-6">Generated Resume Versions</h2>
          
          {resumesLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : resumes && resumes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {resumes.map((resume) => (
                <div key={resume.id} className="bg-card border border-border/50 rounded-2xl p-6 hover:shadow-lg transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 bg-primary/10 text-primary rounded-xl">
                      <FileText className="w-6 h-6" />
                    </div>
                  </div>
                  
                  <h3 className="font-display font-bold text-xl mb-1 capitalize">{resume.industry} Edition</h3>
                  <p className="text-muted-foreground text-sm mb-6">Optimized for ATS systems in the {resume.industry} sector.</p>
                  
                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="flex-1 rounded-xl gap-2" data-testid={`button-view-resume-${resume.id}`}>
                          <Eye className="w-4 h-4" /> View
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle className="capitalize">{resume.industry} Resume</DialogTitle>
                        </DialogHeader>
                        <div className="whitespace-pre-wrap text-sm bg-muted/50 p-4 rounded-lg">
                          {resume.content}
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button 
                      variant="secondary" 
                      className="flex-1 rounded-xl gap-2"
                      onClick={() => handleDownload(resume)}
                      data-testid={`button-download-resume-${resume.id}`}
                    >
                      <Download className="w-4 h-4" /> Download
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-16 text-center border-2 border-dashed border-border/50 rounded-3xl">
              <Wand2 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">No tailored resumes yet</h3>
              <p className="text-muted-foreground max-w-sm mx-auto">
                Click the "Generate" button to create AI-optimized versions of your resume for each industry.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
