import { Sidebar } from "@/components/Sidebar";
import { ComplianceMeter } from "@/components/ComplianceMeter";
import { MonthlyComplianceMeter } from "@/components/MonthlyComplianceMeter";
import { useApplications } from "@/hooks/use-applications";
import { useJobs } from "@/hooks/use-jobs";
import { JobCard } from "@/components/JobCard";
import { useCreateApplication } from "@/hooks/use-applications";
import { Loader2, ArrowRight, Zap } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { data: applications, isLoading: appsLoading } = useApplications();
  const { data: jobs, isLoading: jobsLoading } = useJobs();
  const { mutate: apply, isPending: isApplying } = useCreateApplication();

  const today = new Date().toDateString();
  const dailyQuota = 5;
  const monthlyQuota = 20;
  
  const todaysApps = applications?.filter(app => 
    new Date(app.appliedAt!).toDateString() === today
  ).length || 0;

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const monthlyApps = applications?.filter(app => 
    app.appliedAt && new Date(app.appliedAt) >= monthStart
  ).length || 0;

  const recommendedJobs = jobs?.slice(0, 3) || [];

  return (
    <div className="flex min-h-screen bg-background text-foreground font-body">
      <Sidebar />
      <div className="flex-1 ml-0 md:ml-64 p-4 md:p-8">
        <header className="mb-6 md:mb-10 flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
          <div>
            <h1 className="font-display font-bold text-2xl md:text-3xl mb-2">Welcome Back!</h1>
            <p className="text-muted-foreground text-sm md:text-base">Here's your job search progress for today.</p>
          </div>
          <div className="text-sm text-muted-foreground font-medium bg-muted/50 px-4 py-2 rounded-full border border-border/50">
            {new Date().toLocaleDateString('en-AU', { weekday: 'long', month: 'long', day: 'numeric' })}
          </div>
        </header>

        {/* Monthly Quota - Featured */}
        <div className="mb-8">
          <MonthlyComplianceMeter current={monthlyApps} target={monthlyQuota} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 mb-8 md:mb-12">
          {/* Daily Compliance Meter */}
          <div className="lg:col-span-1">
            <ComplianceMeter current={todaysApps} total={dailyQuota} />
          </div>

          {/* Quick Stats */}
          <div className="lg:col-span-2 grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-primary/5 to-primary/10 border border-primary/20 rounded-2xl p-4 md:p-6 flex flex-col justify-between" data-testid="stat-total-applied">
              <div>
                <h3 className="text-primary font-semibold mb-1 text-sm md:text-base">Total Applied</h3>
                <span className="text-2xl md:text-3xl font-bold font-display">{applications?.length || 0}</span>
              </div>
              <div className="w-full bg-primary/20 h-1.5 rounded-full mt-4">
                <div 
                  className="bg-primary h-1.5 rounded-full transition-all" 
                  style={{ width: `${Math.min(100, ((applications?.length || 0) / 30) * 100)}%` }}
                />
              </div>
            </div>
            <div className="bg-gradient-to-br from-accent/5 to-accent/10 border border-accent/20 rounded-2xl p-4 md:p-6 flex flex-col justify-between" data-testid="stat-auto-applied">
              <div>
                <h3 className="text-yellow-600 dark:text-yellow-400 font-semibold mb-1 text-sm md:text-base flex items-center gap-1">
                  <Zap className="w-4 h-4" /> Auto-Applied
                </h3>
                <span className="text-2xl md:text-3xl font-bold font-display">
                  {applications?.filter(a => a.autoApplied).length || 0}
                </span>
              </div>
              <div className="w-full bg-accent/20 h-1.5 rounded-full mt-4">
                <div 
                  className="bg-accent h-1.5 rounded-full transition-all" 
                  style={{ width: `${applications?.length ? (applications.filter(a => a.autoApplied).length / applications.length * 100) : 0}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Recommended Jobs */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display font-bold text-lg md:text-xl">Top Matches for You</h2>
            <Link href="/jobs">
              <Button variant="ghost" size="sm" className="gap-1" data-testid="link-view-all-jobs">
                View All <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          
          {jobsLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : recommendedJobs.length === 0 ? (
            <div className="bg-card border border-border/50 rounded-2xl p-8 text-center">
              <p className="text-muted-foreground mb-4">No jobs found yet. Click below to scan for matching jobs.</p>
              <Link href="/jobs?scan=true">
                <Button data-testid="button-scan-jobs">Scan for Jobs</Button>
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
              {recommendedJobs.map(job => (
                <JobCard 
                  key={job.id} 
                  job={job} 
                  onApply={(id) => apply({ jobId: id, matchScore: job.matchScore })}
                  isApplied={applications?.some(a => a.jobId === job.id)}
                  isApplying={isApplying}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
