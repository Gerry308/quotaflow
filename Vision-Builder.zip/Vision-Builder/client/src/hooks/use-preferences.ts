import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type UpdatePreferencesRequest } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function usePreferences() {
  return useQuery({
    queryKey: [api.preferences.get.path],
    queryFn: async () => {
      const res = await fetch(api.preferences.get.path, { credentials: "include" });
      if (res.status === 404) return null; // Handle case where prefs don't exist yet
      if (!res.ok) throw new Error("Failed to fetch preferences");
      return api.preferences.get.responses[200].parse(await res.json());
    },
  });
}

export function useUpdatePreferences() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: UpdatePreferencesRequest) => {
      const res = await fetch(api.preferences.update.path, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update preferences");
      return api.preferences.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.preferences.get.path] });
      toast({
        title: "Preferences Saved",
        description: "Your settings have been updated successfully.",
      });
    },
    onError: (err) => {
      toast({
        title: "Error saving preferences",
        description: err.message,
        variant: "destructive",
      });
    },
  });
}
