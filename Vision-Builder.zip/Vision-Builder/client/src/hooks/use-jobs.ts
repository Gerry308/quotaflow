import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type CreateJobRequest } from "@shared/routes";

export function useJobs(scan?: boolean) {
  return useQuery({
    queryKey: [api.jobs.list.path, scan],
    queryFn: async () => {
      // If scanning, we might pass a query param or handle logic differently
      const url = scan 
        ? buildUrl(api.jobs.list.path) + "?scan=true"
        : api.jobs.list.path;
        
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch jobs");
      return api.jobs.list.responses[200].parse(await res.json());
    },
    enabled: true, // Can control this based on state if needed
  });
}

export function useJob(id: number) {
  return useQuery({
    queryKey: [api.jobs.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.jobs.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch job details");
      return api.jobs.get.responses[200].parse(await res.json());
    },
  });
}
