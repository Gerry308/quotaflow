import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

import NotFound from "@/pages/not-found";
import LandingPage from "@/pages/LandingPage";
import Wizard from "@/pages/Wizard";

// Visit tracking temporarily disabled for publishing
function useTrackVisit() {
  // Temporarily disabled
}

function Router() {
  const { user, isLoading } = useAuth();
  const [location] = useLocation();

  // Demo mode - skip auth for presentations
  const isDemoMode = location === "/demo" || location.startsWith("/demo");

  if (isLoading && !isDemoMode) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  // Demo mode goes straight to wizard
  if (isDemoMode) {
    return <Wizard isDemo={true} />;
  }

  if (!user) {
    return (
      <Switch>
        <Route path="/" component={LandingPage} />
        <Route component={LandingPage} />
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path="/">
        <Wizard />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  useTrackVisit();
  
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
